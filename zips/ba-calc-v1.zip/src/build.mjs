import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const R = (p) => path.join(__dirname, p);

const students = JSON.parse(fs.readFileSync(R('data/students.json'), 'utf8'));
const global = JSON.parse(fs.readFileSync(R('data/global.json'), 'utf8'));
const calcSrc = fs.readFileSync(R('calc.js'), 'utf8');
const css = fs.readFileSync(R('ui/app.css'), 'utf8');
const app = fs.readFileSync(R('ui/app.js'), 'utf8');

// 把 ESM 的 export 去掉，包成 IIFE 暴露 CALC（file:// 下不能用 module）
const calcBody = calcSrc.replace(/^export\s+/gm, '');
const calcWrap = `const CALC = (function(){\n${calcBody}\nreturn {
  parseSkillNotation, formatSkillLevels, calcSkillDelta, calcStarDelta, calcEquipDelta,
  calcExpDelta, calcBondDelta, applyInventory, mergeResults, toText
};\n})();`;

const dataJSON = JSON.stringify({ students: students.students, global }).replace(/</g, '\\u003c');

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>蔚蓝档案 · 养成差量计算器</title>
<style>${css}</style>
</head>
<body>
<header class="top">
  <h1>蔚蓝档案 · 养成差量计算器</h1>
  <div class="sub" id="summary"></div>
</header>
<main>
  <section class="picker">
    <div class="tools">
      <input id="q" type="search" placeholder="搜角色：中文名 / 日文名 / 学校">
      <div id="schools" class="chips"></div>
      <div id="stars" class="chips"></div>
    </div>
    <div id="candidates" class="cands"></div>
  </section>

  <section id="plan" class="plan"></section>

  <section class="resultbar">
    <h2>缺口汇总</h2>
    <div class="tools" style="margin:0">
      <label class="sw" style="font-size:12.5px;color:#7d8797">礼物折算 <select id="gift" style="padding:5px 8px;border:1px solid #e3e8ef;border-radius:8px"></select></label>
      <button id="btnCopy" class="btn">复制文本</button>
      <button id="btnExport" class="btn ghost">导出</button>
      <button id="btnImport" class="btn ghost">导入</button>
    </div>
  </section>

  <section id="result" class="result"></section>
</main>

<div id="modal" class="modal">
  <div class="box">
    <h3>粘贴 / 编辑配置 JSON</h3>
    <textarea id="ta" placeholder='{"plan":[...],"inv":{}}'></textarea>
    <div class="row"><button id="mClose" class="btn ghost">关闭</button><button id="mLoad" class="btn">载入</button></div>
  </div>
</div>

<script id="data" type="application/json">${dataJSON}</script>
<script>window.DATA = JSON.parse(document.getElementById('data').textContent);</script>
<script>${calcWrap}</script>
<script>${app}</script>
</body>
</html>
`;

fs.mkdirSync(R('dist'), { recursive: true });
fs.writeFileSync(R('dist/index.html'), html, 'utf8');
console.log('dist/index.html', (html.length / 1024).toFixed(0), 'KB');

// 顺手把内联 JS 抽出来做语法检查
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
fs.writeFileSync(R('dist/_check.js'), scripts.join('\n;\n'), 'utf8');
console.log('scripts:', scripts.length);
