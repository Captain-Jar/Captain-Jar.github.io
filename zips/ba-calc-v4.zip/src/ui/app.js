/* ================= 蔚蓝档案 养成差量计算器 · UI ================= */
(function () {
  const S = DATA.students;
  const T = DATA.global;
  const byId = Object.fromEntries(S.map((s) => [s.id, s]));
  const SCHOOLS = [...new Set(S.map((s) => s.schoolCn))];

  /* ---------------- 图片：SchaleDB 公开素材（jsDelivr 镜像） ---------------- */
  const CDN = 'https://cdn.jsdelivr.net/gh/SchaleDB/SchaleDB@main';
  const studentIcon = (id) => `${CDN}/images/student/icon/${id}.webp`;
  const itemIcon = (icon) => (icon ? `${CDN}/images/item/icon/${icon}.webp` : '');
  const PH = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#e9eff8"/>' +
    '<circle cx="32" cy="26" r="9" fill="#c3cfe2"/><rect x="18" y="40" width="28" height="9" rx="4.5" fill="#c3cfe2"/></svg>');

  function img(src, cls, alt) {
    return `<img class="${cls}" src="${src || PH}" alt="${esc(alt || '')}" loading="lazy" ` +
           `referrerpolicy="no-referrer" onerror="this.onerror=null;this.src='${PH}'">`;
  }

  const GLYPH = { blueprint: '图', enhanceStone: '珠', secretStone: '神', credit: '币' };

  const state = {
    plan: [],            // [{id, cur:{...}, tgt:{...}}]
    inv: {},             // { matKey: number, credit: number }
    q: '',
    school: 'all',
    star: 'all',
    gift: '3★最爱礼物',
  };

  /* ---------------- 状态默认值 ---------------- */
  function baseCfg(s) {
    return {
      star: s.initialStar,
      skill: s.initialStar >= 3 ? '1111' : '1111',
      equips: s.equipment.map(() => ({ tier: 1, level: 1 })),
      level: 1,
      bond: 1,
    };
  }
  function fullCfg(s) {
    return {
      star: 6,
      skill: 'm',
      equips: s.equipment.map(() => ({ tier: 10, level: 10 })),
      level: 90,
      bond: 100,
    };
  }
  function mkEntry(id) {
    const s = byId[id];
    const cur = baseCfg(s);
    return { id, cur, tgt: JSON.parse(JSON.stringify(cur)) };
  }

  /* ---------------- 工具 ---------------- */
  const $ = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
  const num = (n) => (n || 0).toLocaleString('en-US');
  const lv2cfg = (e) => {
    const p = CALC.parseSkillNotation(e.skill);
    return p || { ex: 1, basic: 1, enhance: 1, sub: 1 };
  };

  /* ---------------- 单角色需求 ---------------- */
  function demandOf(e) {
    const s = byId[e.id];
    const tgtS = lv2cfg(e.tgt);
    const skill = CALC.calcSkillDelta(s, lv2cfg(e.cur), tgtS, T);
    const star = CALC.calcStarDelta(s, e.cur.star, e.tgt.star, T);
    const equip = CALC.calcEquipDelta(s, e.cur.equips, e.tgt.equips, T);
    const exp = CALC.calcExpDelta(e.cur.level, e.tgt.level, T);
    const bond = CALC.calcBondDelta(e.cur.bond, e.tgt.bond, T, state.gift);

    // 合并
    const map = new Map();
    const push = (r) => {
      for (const m of r.materials) {
        const cur = map.get(m.key);
        if (cur) cur.n += m.n, cur.by.push({ name: s.name, n: m.n });
        else map.set(m.key, { ...m, by: [{ name: s.name, n: m.n }] });
      }
    };
    push(skill); push(star); push(equip);

    return {
      id: e.id, name: s.name, school: s.schoolCn, initialStar: s.initialStar,
      materials: [...map.values()],
      credit: skill.credit + star.credit + equip.credit + exp.credit,
      exp,
      bond,
      warnings: [...skill.warnings, ...star.warnings, ...equip.warnings],
    };
  }

  /* ---------------- 汇总 ---------------- */
  function computeAll() {
    const per = state.plan.map(demandOf);
    const map = new Map();
    let credit = 0, exp = 0, bondExp = 0;
    const warns = new Set();
    const giftCounts = new Map();

    for (const r of per) {
      for (const m of r.materials) {
        const cur = map.get(m.key);
        if (cur) { cur.n += m.n; cur.by.push(...m.by); }
        else map.set(m.key, { ...m, by: [...m.by] });
      }
      credit += r.credit;
      exp += r.exp.exp;
      bondExp += r.bond.exp;
      r.warnings.forEach((w) => warns.add(w.code + '::' + w.msg));
      for (const g of r.bond.gifts) {
        const c = giftCounts.get(g.name) || { name: g.name, value: g.value, count: 0 };
        c.count += g.count;
        giftCounts.set(g.name, c);
      }
    }
    // 经验书方案（按合计经验重算）
    const plans = [];
    if (exp > 0) {
      const purple = T.books['紫'].exp, gold = T.books['金'].exp;
      const p1 = Math.ceil(exp / purple);
      plans.push({ name: '全紫书', p: p1, g: 0, over: p1 * purple - exp });
      const p2 = Math.max(0, Math.floor(exp / purple) - 1);
      const rest = exp - p2 * purple;
      const g2 = Math.ceil(rest / gold);
      plans.push({ name: '紫+金', p: p2, g: g2, over: p2 * purple + g2 * gold - exp });
      const g3 = Math.ceil(exp / gold);
      plans.push({ name: '全金书', p: 0, g: g3, over: g3 * gold - exp });
    }
    return {
      rows: CALC.applyInventory({ materials: [...map.values()], credit, warnings: [] }, state.inv),
      credit, exp, plans, bondExp, gifts: [...giftCounts.values()],
      warnings: [...warns].map((s) => { const [code, msg] = s.split('::'); return { code, msg }; }),
      per,
    };
  }

  /* ---------------- 渲染：候选 ---------------- */
  function renderCandidates() {
    const q = state.q.trim().toLowerCase();
    const list = S.filter((s) => {
      if (state.school !== 'all' && s.schoolCn !== state.school) return false;
      if (state.star !== 'all' && String(s.initialStar) !== state.star) return false;
      if (state.plan.some((p) => p.id === s.id)) return false;
      if (!q) return true;
      return (s.name + s.nameJp + s.schoolCn).toLowerCase().includes(q);
    });
    $('#candidates').innerHTML = list.length
      ? list.map((s) => `<button class="cand" data-add="${s.id}">
           ${img(studentIcon(s.id), 'cand-ava', s.name)}
           <span class="cand-txt"><span class="nm">${esc(s.name)}</span>
           <span class="meta">${esc(s.schoolCn)} · ${'★'.repeat(s.initialStar)}</span></span>
         </button>`).join('')
      : '<div class="empty">没有可添加的角色（换关键词或清空筛选）</div>';
  }

  /* ---------------- 渲染：规划卡片 ---------------- */
  function cfgHTML(e, which) {
    const s = byId[e.id];
    const c = e[which];
    const p = lv2cfg(c);
    const starOpts = [1, 2, 3, 4, 5, 6].map((v) => {
      const dis = v < s.initialStar ? ' disabled' : '';
      return `<option value="${v}"${c.star === v ? ' selected' : ''}${dis}>${T.starName[v]}</option>`;
    }).join('');
    const eq = s.equipment.map((slot, i) => {
      const t = c.equips[i];
      const tOpts = Array.from({ length: 10 }, (_, k) => k + 1)
        .map((v) => `<option value="${v}"${t.tier === v ? ' selected' : ''}>T${v}</option>`).join('');
      const lOpts = Array.from({ length: 10 }, (_, k) => k + 1)
        .map((v) => `<option value="${v}"${t.level === v ? ' selected' : ''}>Lv${v}</option>`).join('');
      return `<div class="eqrow">
        <span class="eqname">${esc(slot.slotCn)}</span>
        <select data-eq-tier="${i}" data-side="${which}">${tOpts}</select>
        <select data-eq-level="${i}" data-side="${which}">${lOpts}</select>
      </div>`;
    }).join('');

    return `
      <div class="cfg">
        <div class="fld"><label>星级</label>
          <select data-f="star" data-side="${which}">${starOpts}</select></div>
        <div class="fld"><label>技能</label>
          <input data-f="skill" data-side="${which}" value="${esc(c.skill)}" maxlength="4"
                 placeholder="5MMM / 5777 / m">
          <span class="preview">${CALC.formatSkillLevels(p)}</span></div>
        <div class="fld"><label>等级</label>
          <input type="number" min="1" max="90" data-f="level" data-side="${which}" value="${c.level}"></div>
        <div class="fld"><label>好感</label>
          <input type="number" min="1" max="100" data-f="bond" data-side="${which}" value="${c.bond}"></div>
        ${eq}
      </div>`;
  }

  function renderPlan() {
    if (!state.plan.length) {
      $('#plan').innerHTML = '<div class="empty">还没有角色，点上面的候选加入</div>';
      return;
    }
    $('#plan').innerHTML = state.plan.map((e) => {
      const s = byId[e.id];
      return `<article class="card" data-id="${e.id}">
        <header>
          <div class="ttl">
            ${img(studentIcon(s.id), 'ava', s.name)}
            <div class="ttl-txt">
              <b>${esc(s.name)}</b>
              <div class="ttl-sub">
                <span class="tag">${esc(s.schoolCn)}</span>
                <span class="tag star">初始 ${'★'.repeat(s.initialStar)}</span>
              </div>
            </div>
          </div>
          <div class="acts">
            <button class="mini" data-act="full">目标全满</button>
            <button class="mini" data-act="same">当前=目标</button>
            <button class="mini danger" data-act="del">移除</button>
          </div>
        </header>
        <div class="cols">
          <div class="col"><h4>当前</h4>${cfgHTML(e, 'cur')}</div>
          <div class="col"><h4>目标</h4>${cfgHTML(e, 'tgt')}</div>
        </div>
      </article>`;
    }).join('');
  }

  /* ---------------- 渲染：结果 ---------------- */
  let LAST = null;

  function plansHTML(exp) {
    if (exp <= 0) return '<div class="empty">无需经验书</div>';
    const P = T.books['紫'].exp, G = T.books['金'].exp;
    const p1 = Math.ceil(exp / P);
    const p2 = Math.max(0, Math.floor(exp / P) - 1);
    const rest = exp - p2 * P;
    const g2 = Math.ceil(rest / G);
    const g3 = Math.ceil(exp / G);
    return [
      ['全紫书', `紫书 ×${p1}`],
      ['紫+金混合', `紫书 ×${p2} + 金书 ×${g2}`],
      ['全金书', `金书 ×${g3}`],
    ].map(([n, v]) => `<div class="plan"><div class="pn">${n}</div><div class="pv">${v}</div></div>`).join('');
  }

  function expConcl(exp) {
    if (!LAST || !LAST.exp) return '当前等级已达标，无需喂书';
    if (exp <= 0) return '现有经验书已经够用，不需要再补';
    return `库存抵扣后还需 ${num(exp)} 经验 → 约 ${Math.ceil(exp / 2000)} 本金书（或 ${Math.ceil(exp / 10000)} 本紫书）`;
  }

  function giftListOf() {
    return Object.entries(T.gifts).filter(([, v]) => typeof v === 'number');
  }

  function bondPlansHTML(exp) {
    if (exp <= 0) return '<div class="empty">无需礼物</div>';
    return giftListOf().map(([n, v]) =>
      `<div class="plan"><div class="pn">${esc(n)}</div><div class="pv">× ${num(Math.ceil(exp / v))}</div>` +
      `<div class="po">单个 ${v} 经验</div></div>`).join('');
  }

  function bondConcl(exp) {
    if (!LAST || !LAST.bondExp) return '好感已达标，无需送礼';
    if (exp <= 0) return '现有礼物已经够用，不需要再补';
    const best = [...giftListOf()].sort((a, b) => b[1] - a[1])[0];
    return `库存抵扣后还需 ${num(exp)} 好感 → 还需 ${Math.ceil(exp / best[1])} 个${esc(best[0])}`;
  }

  function refreshExp() {
    if (!LAST) return;
    const have = ['紫', '金', '蓝', '白'].reduce((a, k) => a + Number(state.inv['book:' + k] || 0) * T.books[k].exp, 0);
    const left = Math.max(0, LAST.exp - have);
    $('#expPlans').innerHTML = plansHTML(left);
    $('#expConcl').textContent = expConcl(left);
  }

  function refreshBond() {
    if (!LAST) return;
    const have = giftListOf().reduce((a, [n, v]) => a + Number(state.inv['gift:' + n] || 0) * v, 0);
    const left = Math.max(0, LAST.bondExp - have);
    $('#bondPlans').innerHTML = bondPlansHTML(left);
    $('#bondConcl').textContent = bondConcl(left);
  }

  function renderResult() {
    const r = computeAll();
    LAST = r;
    const rows = r.rows.rows;

    const bookInv = ['紫', '金', '蓝', '白'].map((k) => ({ k, n: Number(state.inv['book:' + k] || 0), exp: T.books[k].exp }));
    const bookExp = bookInv.reduce((a, b) => a + b.n * b.exp, 0);
    const expLeft = Math.max(0, r.exp - bookExp);

    const giftList = giftListOf();
    const giftExpHave = giftList.reduce((a, [n, v]) => a + (Number(state.inv['gift:' + n] || 0) * v), 0);
    const bondLeft = Math.max(0, r.bondExp - giftExpHave);

    const groups = { skill: [], stone: [], equip: [] };
    for (const m of rows) {
      if (m.kind === 'blueprint' || m.kind === 'enhanceStone') groups.equip.push(m);
      else if (m.kind === 'secretStone') groups.stone.push(m);
      else groups.skill.push(m);
    }

    const rowHTML = (m) => {
      const ico = m.icon
        ? img(itemIcon(m.icon), 'mico', m.base)
        : `<span class="mico glyph g-${m.kind}">${GLYPH[m.kind] || '·'}</span>`;
      return `<div class="mrow${m.satisfied ? ' ok' : ''}" data-key="${esc(m.key)}">
        ${ico}
        <div class="mtext">
          <div class="mname">${esc(m.label)}</div>
          <div class="mmeta">${esc((T.kindLabels || {})[m.kind] || '')}${
            m.by && m.by.length > 1
              ? ` · <button class="peek" data-peek="${esc(m.key)}">谁要的 ${m.by.length}</button>` : ''}</div>
          <div class="src" hidden>${(m.by || []).map((x) => `${esc(x.name)} ×${x.n}`).join('　')}</div>
        </div>
        <div class="mright">
          <div class="stat"><span>需求</span><b>${num(m.need)}</b></div>
          <label class="pillinv"><span>持有</span>
            <input class="inv" type="number" min="0" data-inv="${esc(m.key)}" value="${m.have || ''}" placeholder="0"></label>
          <div class="stat gapstat"><span>缺口</span><b class="gapnum gap">${m.satisfied ? 0 : num(m.gap)}</b></div>
          ${m.satisfied ? '<span class="okbadge">已满足</span>' : ''}
        </div>
      </div>`;
    };

    const section = (title, list, note) => list.length
      ? `<h3>${title}${note ? `<small>${note}</small>` : ''}</h3><div class="mlist">${list.map(rowHTML).join('')}</div>`
      : '';

    const creditRow = `<h3>信用点<small>技能 / 等级 / 装备合计</small></h3>
      <div class="mlist"><div class="mrow${r.rows.credit.satisfied ? ' ok' : ''}" data-key="credit">
        <span class="mico glyph g-credit">币</span>
        <div class="mtext"><div class="mname">信用点</div><div class="mmeta">经验 × 7</div></div>
        <div class="mright">
          <div class="stat"><span>需求</span><b>${num(r.rows.credit.need)}</b></div>
          <label class="pillinv"><span>持有</span>
            <input class="inv" type="number" min="0" data-inv="credit" value="${r.rows.credit.have || ''}" placeholder="0"></label>
          <div class="stat gapstat"><span>缺口</span><b class="gapnum gap">${r.rows.credit.satisfied ? 0 : num(r.rows.credit.gap)}</b></div>
          ${r.rows.credit.satisfied ? '<span class="okbadge">已满足</span>' : ''}
        </div>
      </div></div>`;

    const expHTML = `<h3>角色经验<small>1→90 共 ${num(1249185)}</small></h3>
      <div class="box">
        <div class="kv"><span>还需经验</span><b>${num(r.exp)}</b></div>
        <div class="hint">以下为多种喂书方案，任选其一即可（OR）</div>
        <div class="plans" id="expPlans">${plansHTML(expLeft)}</div>
        <details class="invbox"${bookExp ? ' open' : ''}>
          <summary>填入我现有的经验书，优先扣库存</summary>
          <div class="invrow">${bookInv.map((b) => `<label class="bk">${b.k}书<input type="number" min="0" data-book="${b.k}" value="${state.inv['book:' + b.k] || ''}" placeholder="0"></label>`).join('')}</div>
        </details>
        <div class="concl" id="expConcl">${expConcl(expLeft)}</div>
      </div>`;

    const bondHTML = `<h3 class="bond">好感度（独立模块，不计入材料缺口）</h3>
      <div class="box bond">
        <div class="kv"><span>还需好感经验</span><b>${num(r.bondExp)}</b></div>
        <div class="hint">以下为不同礼物折算方案，任选其一即可（OR）</div>
        <div class="plans" id="bondPlans">${bondPlansHTML(bondLeft)}</div>
        <details class="invbox"${giftExpHave ? ' open' : ''}>
          <summary>填入我现有的礼物，优先扣库存</summary>
          <div class="invrow">${giftList.map(([n]) => `<label class="bk">${esc(n)}<input type="number" min="0" data-gift="${esc(n)}" value="${state.inv['gift:' + n] || ''}" placeholder="0"></label>`).join('')}</div>
        </details>
        <div class="concl" id="bondConcl">${bondConcl(bondLeft)}</div>
      </div>`;

    const warnHTML = r.warnings.length ? `<div class="note">
      ${r.warnings.map((w) => `<div>${esc(w.msg)}</div>`).join('')}
    </div>` : '';

    $('#result').innerHTML = `
      ${section('技能材料', groups.skill, '按 学校 + 稀有度 + 古物名 分组')}
      ${section('升星 / 专精（神明文字）', groups.stone)}
      ${section('装备', groups.equip, '图纸与强化珠分开')}
      ${creditRow}
      ${expHTML}
      ${bondHTML}
      ${warnHTML}`;

    $('#summary').textContent = state.plan.length
      ? `${state.plan.length} 名角色 · 材料 ${rows.length} 行 · 信用点 ${num(r.credit)}`
      : '把角色加入规划后自动计算';
  }

  /* ---------------- 文本导出 ---------------- */
  function buildText() {
    const r = computeAll();
    const L = ['蔚蓝档案 · 养成缺口', `角色：${state.plan.map((e) => byId[e.id].name).join('、')}`, ''];
    const push = (title, list) => {
      if (!list.length) return;
      L.push(`【${title}】`);
      for (const m of list) L.push(`${m.label} ×${m.need}${m.satisfied ? '（已满足）' : `（缺 ${m.gap}）`}`);
      L.push('');
    };
    push('技能材料', r.rows.rows.filter((m) => ['bd', 'note', 'artifact'].includes(m.kind)));
    push('神明文字', r.rows.rows.filter((m) => m.kind === 'secretStone'));
    push('装备', r.rows.rows.filter((m) => ['blueprint', 'enhanceStone'].includes(m.kind)));
    L.push(`【信用点】需 ${num(r.credit)}${r.rows.credit.satisfied ? '（已满足）' : `（缺 ${num(r.rows.credit.gap)}）`}`);
    if (r.exp) L.push(`\n【角色经验】还需 ${num(r.exp)}`, ...r.plans.map((p) => `  ${p.name}：${p.p ? `紫书×${p.p} ` : ''}${p.g ? `金书×${p.g}` : ''}`));
    if (r.bondExp) L.push(`\n【好感度】还需 ${num(r.bondExp)}`, ...r.gifts.map((g) => `  ${g.name} ×${g.count}`));
    return L.join('\n');
  }

  /* ---------------- 事件 ---------------- */
  function bind() {
    $('#q').addEventListener('input', (e) => { state.q = e.target.value; renderCandidates(); });

    $('#schools').addEventListener('click', (e) => {
      const b = e.target.closest('[data-school]');
      if (!b) return;
      state.school = b.dataset.school;
      $$('#schools .chip').forEach((c) => c.classList.toggle('on', c.dataset.school === state.school));
      renderCandidates();
    });
    $('#stars').addEventListener('click', (e) => {
      const b = e.target.closest('[data-star]');
      if (!b) return;
      state.star = b.dataset.star;
      $$('#stars .chip').forEach((c) => c.classList.toggle('on', c.dataset.star === state.star));
      renderCandidates();
    });

    $('#candidates').addEventListener('click', (e) => {
      const b = e.target.closest('[data-add]');
      if (!b) return;
      state.plan.push(mkEntry(Number(b.dataset.add)));
      renderCandidates(); renderPlan(); renderResult(); save();
    });

    $('#plan').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-act]');
      const card = e.target.closest('.card');
      if (!card) return;
      const id = Number(card.dataset.id);
      const e0 = state.plan.find((p) => p.id === id);
      if (!e0) return;
      if (btn) {
        const act = btn.dataset.act;
        if (act === 'del') state.plan = state.plan.filter((p) => p.id !== id);
        if (act === 'full') e0.tgt = fullCfg(byId[id]);
        if (act === 'same') e0.tgt = JSON.parse(JSON.stringify(e0.cur));
        renderCandidates(); renderPlan(); renderResult(); save();
        return;
      }
    });

    $('#plan').addEventListener('input', (e) => {
      const el = e.target;
      const card = el.closest('.card');
      if (!card) return;
      const e0 = state.plan.find((p) => p.id === Number(card.dataset.id));
      if (!e0) return;
      const side = el.dataset.side || 'cur';
      const t = el.dataset;
      if (t.f === 'skill') {
        e0[side].skill = el.value;
        const pv = el.parentElement.querySelector('.preview');
        const p = CALC.parseSkillNotation(el.value);
        pv.textContent = p ? CALC.formatSkillLevels(p) : '格式错误';
        pv.classList.toggle('bad', !p);
      } else if (t.f) {
        e0[side][t.f] = Number(el.value);
      } else if (t.eqTier !== undefined) {
        e0[side].equips[Number(t.eqTier)].tier = Number(el.value);
      } else if (t.eqLevel !== undefined) {
        e0[side].equips[Number(t.eqLevel)].level = Number(el.value);
      }
      renderResult(); save();
    });

    $('#plan').addEventListener('change', (e) => {
      if (e.target.tagName === 'SELECT') renderResult();
    });

    $('#result').addEventListener('input', (e) => {
      const bookEl = e.target.closest('[data-book]');
      if (bookEl) {
        state.inv['book:' + bookEl.dataset.book] = Number(bookEl.value) || 0;
        refreshExp(); save(); return;
      }
      const giftEl = e.target.closest('[data-gift]');
      if (giftEl) {
        state.inv['gift:' + giftEl.dataset.gift] = Number(giftEl.value) || 0;
        refreshBond(); save(); return;
      }
      const el = e.target.closest('[data-inv]');
      if (!el) return;
      state.inv[el.dataset.inv] = Number(el.value) || 0;
      const r = computeAll();
      // 只更新缺口，避免输入时失焦
      const row = el.closest('.mrow');
      const m = r.rows.rows.find((x) => x.key === el.dataset.inv) ||
                (el.dataset.inv === 'credit' ? r.rows.credit : null);
      if (m && row) {
        const cell = row.querySelector('.gap');
        if (cell) cell.textContent = m.satisfied ? '0' : num(m.gap);
        row.classList.toggle('ok', m.satisfied);
        const badge = row.querySelector('.okbadge');
        if (m.satisfied && !badge) {
          const b = document.createElement('span');
          b.className = 'okbadge';
          b.textContent = '已满足';
          row.querySelector('.mright').appendChild(b);
        } else if (!m.satisfied && badge) badge.remove();
      }
      save();
    });

    $('#result').addEventListener('click', (e) => {
      const p = e.target.closest('[data-peek]');
      if (!p) return;
      const src = p.parentElement.querySelector('.src');
      if (src) src.hidden = !src.hidden;
    });

    $('#btnCopy').addEventListener('click', async () => {
      const txt = buildText();
      try { await navigator.clipboard.writeText(txt); toast('已复制到剪贴板'); }
      catch { $('#ta').value = txt; $('#modal').classList.add('on'); }
    });
    $('#btnExport').addEventListener('click', () => {
      const blob = new Blob([JSON.stringify({ v: 1, plan: state.plan, inv: state.inv, gift: state.gift }, null, 1)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'ba-plan.json';
      a.click();
    });
    $('#btnImport').addEventListener('click', () => $('#modal').classList.add('on'));
    $('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal' || e.target.id === 'mClose') $('#modal').classList.remove('on'); });
    $('#mLoad').addEventListener('click', () => {
      try {
        const d = JSON.parse($('#ta').value);
        state.plan = (d.plan || []).filter((x) => byId[x.id]);
        state.inv = d.inv || {};
        if (d.gift) state.gift = d.gift;
        $('#modal').classList.remove('on');
        renderCandidates(); renderPlan(); renderResult(); save();
      } catch { toast('JSON 解析失败'); }
    });
    $('#gift').addEventListener('change', (e) => { state.gift = e.target.value; renderResult(); save(); });
  }

  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1600);
  }

  function save() {
    try { localStorage.setItem('ba-calc', JSON.stringify({ plan: state.plan, inv: state.inv, gift: state.gift })); } catch {}
  }
  function load() {
    try {
      const d = JSON.parse(localStorage.getItem('ba-calc') || 'null');
      if (!d) return;
      state.plan = (d.plan || []).filter((x) => byId[x.id]);
      state.inv = d.inv || {};
      state.gift = d.gift || state.gift;
    } catch {}
  }

  /* ---------------- 初始化 ---------------- */
  function init() {
    $('#schools').innerHTML = ['all', ...SCHOOLS]
      .map((s) => `<button class="chip${s === 'all' ? ' on' : ''}" data-school="${s}">${s === 'all' ? '全部学校' : s}</button>`).join('');
    $('#stars').innerHTML = ['all', '3', '2', '1']
      .map((s) => `<button class="chip${s === 'all' ? ' on' : ''}" data-star="${s}">${s === 'all' ? '全部星级' : s + '★'}</button>`).join('');
    $('#gift').innerHTML = Object.keys(T.gifts).filter((k) => typeof T.gifts[k] === 'number')
      .map((k) => `<option value="${k}"${k === state.gift ? ' selected' : ''}>${k}</option>`).join('');
    load();
    bind();
    renderCandidates(); renderPlan(); renderResult();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
