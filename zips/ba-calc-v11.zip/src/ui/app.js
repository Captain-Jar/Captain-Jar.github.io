/* ================= 蔚蓝档案 养成差量计算器 · UI ================= */
(function () {
  const S = DATA.students;
  const T = DATA.global;
  const byId = Object.fromEntries(S.map((s) => [s.id, s]));
  const SCHOOLS = [...new Set(S.map((s) => s.schoolCn))];

  /* ---------------- 图片：SchaleDB 素材，jsDelivr 主源 + GitHub raw 备源 ---------------- */
  const CDN = 'https://cdn.jsdelivr.net/gh/SchaleDB/SchaleDB@main';
  const CDN2 = 'https://raw.githubusercontent.com/SchaleDB/SchaleDB/main';
  const studentIcon = (id) => `${CDN}/images/student/icon/${id}.webp`;
  const itemIcon = (icon) => (icon ? `${CDN}/images/item/icon/${icon}.webp` : '');
  /** 支持 "item:xxx" / "eq:xxx" 前缀，用于图纸/强化珠/神名精髓等公共素材 */
  const iconUrl = (v) => {
    if (!v) return '';
    const idx = String(v).indexOf(':');
    const pfx = idx > 0 ? v.slice(0, idx) : 'item';
    const name = idx > 0 ? v.slice(idx + 1) : v;
    const sub = pfx === 'eq' ? 'equipment' : 'item';
    return `${CDN}/images/${sub}/icon/${name}.webp`;
  };
  const PH = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#e9eff8"/>' +
    '<circle cx="32" cy="26" r="9" fill="#c3cfe2"/><rect x="18" y="40" width="28" height="9" rx="4.5" fill="#c3cfe2"/></svg>');

  function img(src, cls, alt) {
    const fb = src && src.startsWith(CDN) ? src.replace(CDN, CDN2) : '';
    return `<img class="${cls}" src="${src || PH}" data-fb="${fb}" alt="${esc(alt || '')}" loading="lazy" ` +
           `referrerpolicy="no-referrer" onerror="var f=this.dataset.fb;` +
           `if(f&&f!==this.src){this.src=f;this.dataset.fb='';}else{this.style.display='none';}">`;
  }

  const GLYPH = { blueprint: '图', enhanceStone: '珠', secretStone: '神', credit: '币' };

  /* ---------------- 礼物：SchaleDB 真实礼物 + 每人 tag 匹配 ---------------- */
  const GIFTS = DATA.gifts || [];
  const GIFT_VALUE = {
    2: { beloved: 80, favorite: 60, liked: 40, normal: 20 },
    3: { beloved: 240, favorite: 180, liked: 120 },
  };

  /** 返回该学生「超爱 / 最爱」的礼物（按好感值降序） */
  function favGifts(s) {
    if (!s || !GIFTS.length) return [];
    const uniq = new Set(s.giftUnique || []);
    const tags = new Set(s.giftTags || []);
    const out = [];
    for (const g of GIFTS) {
      const gt = g.tags || [];
      const beloved = gt.some((t) => uniq.has(t));
      const favorite = gt.some((t) => tags.has(t));
      if (!beloved && !favorite) continue;
      const tier = g.tier || (g.rarity === 'SSR' ? 3 : 2);
      out.push({ ...g, tier, beloved, value: GIFT_VALUE[tier][beloved ? 'beloved' : 'favorite'] });
    }
    return out.sort((a, b) => b.value - a.value || a.id - b.id);
  }

  const state = {
    plan: [],            // [{id, cur:{...}, tgt:{...}}]
    inv: {},             // { matKey: number, credit: number }
    q: '',
    school: 'all',
    star: 'all',
    gift: '3★最爱礼物',
    theme: null,
  };

  /* ---------------- 状态默认值 ---------------- */
  function baseCfg(s) {
    return {
      star: s.initialStar,
      skill: s.initialStar >= 3 ? '1111' : '1111',
      equips: s.equipment.map(() => ({ tier: 1, level: 1 })),
      level: 1,
      bond: 1,
    };
  }
  function fullCfg(s) {
    return {
      star: 6,
      skill: 'm',
      equips: s.equipment.map(() => ({ tier: 10, level: 10 })),
      level: 90,
      bond: 100,
    };
  }
  function mkEntry(id) {
    const s = byId[id];
    const cur = baseCfg(s);
    return { id, cur, tgt: JSON.parse(JSON.stringify(cur)), love: false, weapon: null };
  }

  /* 养成建议（社区通识规则，非官方） */
  const ROLE_ADVICE = {
    DamageDealer: '输出：优先把 EX 拉到 5，再利用活动材料把基础/强化补到 7；M 技能性价比低于 EX。',
    Healer: '治疗：5777 性价比最高，EX 只在治疗量吃紧时上 5。',
    Supporter: '辅助：5777 通常够用，EX 按需 3→5，先看 buff 数值门槛。',
    Tanker: '坦克：5777 优先，装备 T 阶带来的收益往往高于继续点技能。',
    Vehicle: '载具：EX 与装备优先，普通技能 7 级即可。',
  };
  const ROLE_CN = { DamageDealer: '输出', Healer: '治疗', Supporter: '辅助', Tanker: '坦克', Vehicle: '载具' };

  /* ---------------- 工具 ---------------- */
  const $ = (sel, el = document) => el.querySelector(sel);
  const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
  const num = (n) => (n || 0).toLocaleString('en-US');
  const lv2cfg = (e) => {
    const p = CALC.parseSkillNotation(e.skill);
    return p || { ex: 1, basic: 1, enhance: 1, sub: 1 };
  };

  /* ---------------- 单角色需求 ---------------- */
  function demandOf(e) {
    const s = byId[e.id];
    const tgtS = lv2cfg(e.tgt);
    const skill = CALC.calcSkillDelta(s, lv2cfg(e.cur), tgtS, T);
    const star = CALC.calcStarDelta(s, e.cur.star, e.tgt.star, T);
    const equip = CALC.calcEquipDelta(s, e.cur.equips, e.tgt.equips, T);
    const exp = CALC.calcExpDelta(e.cur.level, e.tgt.level, T);
    const bond = CALC.calcBondDelta(e.cur.bond, e.tgt.bond, T, state.gift);

    // 合并
    const map = new Map();
    const push = (r) => {
      for (const m of r.materials) {
        const cur = map.get(m.key);
        if (cur) {
          cur.n += m.n;
          if (m.expNeeded) cur.expNeeded = (cur.expNeeded || 0) + m.expNeeded;
          cur.by.push({ name: s.name, n: m.n });
        } else map.set(m.key, { ...m, by: [{ name: s.name, n: m.n }] });
      }
    };
    push(skill); push(star); push(equip);

    // 爱用品（数据来自 students.json 的 loveItem，没有则不算）
    if (e.love && s.loveItem) {
      for (const c of s.loveItem.tierUp) {
        const key = `love|${s.school}|${c.rarity}|${c.base}`;
        const cur = map.get(key);
        if (cur) { cur.n += c.n; cur.by.push({ name: s.name, n: c.n }); }
        else map.set(key, {
          key, kind: c.kind, school: s.school, schoolCn: s.schoolCn,
          rarity: c.rarity, base: c.base, n: c.n, icon: c.icon || null,
          label: `${s.schoolCn} ${c.base} ${c.rarity}`,
          by: [{ name: s.name, n: c.n }],
        });
      }
    }

    return {
      id: e.id, name: s.name, school: s.schoolCn, initialStar: s.initialStar,
      materials: [...map.values()],
      credit: skill.credit + star.credit + equip.credit + exp.credit,
      exp,
      bond,
      warnings: [...skill.warnings, ...star.warnings, ...equip.warnings],
    };
  }

  /* ---------------- 汇总 ---------------- */
  function computeAll() {
    const per = state.plan.map(demandOf);
    const map = new Map();
    let credit = 0, exp = 0, bondExp = 0;
    const warns = new Set();
    const giftCounts = new Map();

    for (const r of per) {
      for (const m of r.materials) {
        const cur = map.get(m.key);
        if (cur) {
          cur.n += m.n;
          if (m.expNeeded) cur.expNeeded = (cur.expNeeded || 0) + m.expNeeded;
          cur.by.push(...m.by);
        } else map.set(m.key, { ...m, by: [...m.by] });
      }
      credit += r.credit;
      exp += r.exp.exp;
      bondExp += r.bond.exp;
      r.warnings.forEach((w) => warns.add(w.code + '::' + w.msg));
      for (const g of r.bond.gifts) {
        const c = giftCounts.get(g.name) || { name: g.name, value: g.value, count: 0 };
        c.count += g.count;
        giftCounts.set(g.name, c);
      }
    }
    // 经验书方案（按合计经验重算）
    const plans = [];
    if (exp > 0) {
      const purple = T.books['紫'].exp, gold = T.books['金'].exp;
      const p1 = Math.ceil(exp / purple);
      plans.push({ name: '全紫书', p: p1, g: 0, over: p1 * purple - exp });
      const p2 = Math.max(0, Math.floor(exp / purple) - 1);
      const rest = exp - p2 * purple;
      const g2 = Math.ceil(rest / gold);
      plans.push({ name: '紫+金', p: p2, g: g2, over: p2 * purple + g2 * gold - exp });
      const g3 = Math.ceil(exp / gold);
      plans.push({ name: '全金书', p: 0, g: g3, over: g3 * gold - exp });
    }
    return {
      rows: CALC.applyInventory({ materials: [...map.values()], credit, warnings: [] }, state.inv),
      credit, exp, plans, bondExp, gifts: [...giftCounts.values()],
      warnings: [...warns].map((s) => { const [code, msg] = s.split('::'); return { code, msg }; }),
      per,
    };
  }

  /* ---------------- 渲染：候选 ---------------- */
  function renderCandidates() {
    const q = state.q.trim().toLowerCase();
    const list = S.filter((s) => {
      if (state.school !== 'all' && s.schoolCn !== state.school) return false;
      if (state.star !== 'all' && String(s.initialStar) !== state.star) return false;
      if (state.plan.some((p) => p.id === s.id)) return false;
      if (!q) return true;
      return (s.name + s.nameJp + s.schoolCn).toLowerCase().includes(q);
    });
    $('#candidates').innerHTML = list.length
      ? list.map((s) => `<button class="cand" data-add="${s.id}">
           ${img(studentIcon(s.id), 'cand-ava', s.name)}
           <span class="cand-txt"><span class="nm">${esc(s.name)}</span>
           <span class="meta">${esc(s.schoolCn)} · ${'★'.repeat(s.initialStar)}</span></span>
         </button>`).join('')
      : '<div class="empty">没有可添加的角色（换关键词或清空筛选）</div>';
  }

  /* ---------------- 渲染：规划卡片 ---------------- */
  function cfgHTML(e, which) {
    const s = byId[e.id];
    const c = e[which];
    const p = lv2cfg(c);
    const starOpts = [1, 2, 3, 4, 5, 6].map((v) => {
      const dis = v < s.initialStar ? ' disabled' : '';
      return `<option value="${v}"${c.star === v ? ' selected' : ''}${dis}>${T.starName[v]}</option>`;
    }).join('');
    const eq = s.equipment.map((slot, i) => {
      const t = c.equips[i];
      const tOpts = Array.from({ length: 10 }, (_, k) => k + 1)
        .map((v) => `<option value="${v}"${t.tier === v ? ' selected' : ''}>T${v}</option>`).join('');
      const lOpts = Array.from({ length: 10 }, (_, k) => k + 1)
        .map((v) => `<option value="${v}"${t.level === v ? ' selected' : ''}>Lv${v}</option>`).join('');
      return `<div class="eqrow">
        <span class="eqname">${esc(slot.slotCn)}</span>
        <select data-eq-tier="${i}" data-side="${which}">${tOpts}</select>
        <select data-eq-level="${i}" data-side="${which}">${lOpts}</select>
      </div>`;
    }).join('');

    return `
      <div class="cfg">
        <div class="fld"><label>星级</label>
          <select data-f="star" data-side="${which}">${starOpts}</select></div>
        <div class="fld"><label>技能</label>
          <input data-f="skill" data-side="${which}" value="${esc(c.skill)}" maxlength="4"
                 placeholder="5MMM / 5777 / m">
          <span class="preview">${CALC.formatSkillLevels(p)}</span></div>
        <div class="fld"><label>等级</label>
          <input type="number" min="1" max="90" data-f="level" data-side="${which}" value="${c.level}"></div>
        <div class="fld"><label>好感</label>
          <input type="number" min="1" max="100" data-f="bond" data-side="${which}" value="${c.bond}"></div>
        ${eq}
      </div>`;
  }

  function renderPlan() {
    if (!state.plan.length) {
      $('#plan').innerHTML = '<div class="empty">还没有角色，点上面的候选加入</div>';
      return;
    }
    $('#plan').innerHTML = state.plan.map((e) => {
      const s = byId[e.id];
      return `<article class="card" data-id="${e.id}">
        <header>
          <div class="ttl">
            ${img(studentIcon(s.id), 'ava', s.name)}
            <div class="ttl-txt">
              <b>${esc(s.name)}</b>
              <div class="ttl-sub">
                <span class="tag">${esc(s.schoolCn)}</span>
                <span class="tag star">初始 ${'★'.repeat(s.initialStar)}</span>
              </div>
            </div>
          </div>
          <div class="acts">
            <button class="mini" data-act="full">目标全满</button>
            <button class="mini" data-act="same">当前=目标</button>
            <button class="mini danger" data-act="del">移除</button>
          </div>
        </header>
        <div class="opts">
          ${s.loveItem
            ? `<label class="opt"><input type="checkbox" data-love="${s.id}"${e.love ? ' checked' : ''}>
                 算上爱用品 <small>${esc(s.loveItem.name)}</small></label>`
            : '<span class="opt off">爱用品：暂无数据</span>'}
          <span class="opt off">专武：暂无数据</span>
          <span class="opt role">定位：${esc(ROLE_CN[s.role] || s.role || '未知')}</span>
        </div>
        <div class="advice">💡 ${esc(ROLE_ADVICE[s.role] || '按需培养：先把 EX 与关键技能拉到 7，再决定是否冲 M。')}</div>
        <div class="favrow">
          <span class="favlabel">最爱礼物</span>
          ${favGifts(s).slice(0, 6).map((g) => `<span class="favico" title="${esc(g.name)} · ${g.beloved ? '超爱' : '喜欢'} +${g.value}">
            ${img(itemIcon(g.icon), 'favimg', g.name)}<i>${g.beloved ? '💖' : '❤'}</i></span>`).join('')
            || '<span class="opt off">暂无礼物偏好数据</span>'}
        </div>
        <div class="cols">
          <div class="col"><h4>当前</h4>${cfgHTML(e, 'cur')}</div>
          <div class="col"><h4>目标</h4>${cfgHTML(e, 'tgt')}</div>
        </div>
      </article>`;
    }).join('');
  }

  /* ---------------- 渲染：结果 ---------------- */
  let LAST = null;

  function bookIco(k) {
    const src = T.icons && T.icons.books ? T.icons.books[k] : '';
    return src ? `<img class="pico" src="${iconUrl(src)}" alt="${k}书" loading="lazy" referrerpolicy="no-referrer"
      onerror="this.style.display='none'">` : '';
  }

  function plansHTML(exp) {
    if (exp <= 0) return '<div class="empty">无需经验书</div>';
    const P = T.books['紫'].exp, G = T.books['金'].exp;
    const p1 = Math.ceil(exp / P);
    const p2 = Math.max(0, Math.floor(exp / P) - 1);
    const rest = exp - p2 * P;
    const g2 = Math.ceil(rest / G);
    const g3 = Math.ceil(exp / G);
    return [
      ['全紫书', `${bookIco('紫')}紫书 ×${p1}`],
      ['紫+金混合', `${bookIco('紫')}紫书 ×${p2} + ${bookIco('金')}金书 ×${g2}`],
      ['全金书', `${bookIco('金')}金书 ×${g3}`],
    ].map(([n, v]) => `<div class="plan"><div class="pn">${n}</div><div class="pv">${v}</div></div>`).join('');
  }

  function altHTML(exp) {
    if (exp <= 0) return '';
    const g = Math.floor(exp / 2000);
    const rest = exp - g * 2000;
    const b = Math.ceil(rest / 500);
    return `若紫书不足：可用 <b>${num(g)}</b> 本金书${b ? ` + <b>${b}</b> 本蓝书` : ''} 替代`;
  }

  function expConcl(exp) {
    if (!LAST || !LAST.exp) return '当前等级已达标，无需喂书';
    if (exp <= 0) return '现有经验书已经够用，不需要再补';
    return `库存抵扣后还需 ${num(exp)} 经验 → 约 ${Math.ceil(exp / 2000)} 本金书（或 ${Math.ceil(exp / 10000)} 本紫书）`;
  }

  function giftListOf() {
    return Object.entries(T.gifts).filter(([, v]) => typeof v === 'number');
  }

  function bondPlansHTML(exp) {
    if (exp <= 0) return '<div class="empty">无需礼物</div>';
    return giftListOf().map(([n, v]) =>
      `<div class="plan"><div class="pn">${esc(n)}</div><div class="pv">× ${num(Math.ceil(exp / v))}</div>` +
      `<div class="po">单个 ${v} 经验</div></div>`).join('');
  }

  function bondConcl(exp) {
    if (!LAST || !LAST.bondExp) return '好感已达标，无需送礼';
    if (exp <= 0) return '现有礼物已经够用，不需要再补';
    const best = [...giftListOf()].sort((a, b) => b[1] - a[1])[0];
    return `库存抵扣后还需 ${num(exp)} 好感 → 还需 ${Math.ceil(exp / best[1])} 个${esc(best[0])}`;
  }

  function refreshExp() {
    if (!LAST) return;
    const have = ['紫', '金', '蓝', '白'].reduce((a, k) => a + Number(state.inv['book:' + k] || 0) * T.books[k].exp, 0);
    const left = Math.max(0, LAST.exp - have);
    $('#expPlans').innerHTML = plansHTML(left);
    $('#expAlt').innerHTML = altHTML(left);
    $('#expConcl').textContent = expConcl(left);
  }

  function refreshBond() {
    if (!LAST) return;
    const have = giftListOf().reduce((a, [n, v]) => a + Number(state.inv['gift:' + n] || 0) * v, 0);
    const left = Math.max(0, LAST.bondExp - have);
    $('#bondPlans').innerHTML = bondPlansHTML(left);
    $('#bondConcl').textContent = bondConcl(left);
  }

  /* ---------------- 仓库批量录入 ---------------- */
  function repoGroups() {
    const r = LAST;
    if (!r) return [];
    const rows = r.rows.rows;
    const g = [];
    const push = (t, list) => { if (list.length) g.push([t, list]); };
    push('战术教育 BD / 技术笔记', rows.filter((m) => m.kind === 'bd' || m.kind === 'note').sort(byRarity));
    push('古物', rows.filter((m) => m.kind === 'artifact').sort(byRarity));
    push('装备图纸（T 阶从高到低）', rows.filter((m) => m.kind === 'blueprint').sort(byTierDesc));
    push('强化珠', [...SYNTH.values()].filter((m) => m.kind === 'enhanceStone'));
    push('神明文字', rows.filter((m) => m.kind === 'secretStone'));
    push('经验书', [...SYNTH.values()].filter((m) => m.kind === 'book'));
    return g;
  }

  function repoItem(iconHTML, label, sub, invKey) {
    const have = Number(state.inv[invKey] || 0);
    return `<label class="repo-item">
      ${iconHTML}
      <span class="repo-name">${esc(label)}${sub ? `<small>${sub}</small>` : ''}</span>
      <input type="number" min="0" inputmode="numeric" data-repo="${esc(invKey)}" value="${have || ''}" placeholder="0">
    </label>`;
  }

  function renderRepo() {
    const body = $('#repoBody');
    if (!body) return;
    if (!state.plan.length) {
      body.innerHTML = '<div class="empty">先在上方加入角色，再回来填仓库</div>';
      $('#repoCount').textContent = '';
      return;
    }
    const groups = repoGroups();
    const giftHTML = `<section class="repo-sec"><h4>礼物</h4><div class="repo-grid">${
      giftListOf().map(([n, v]) => repoItem(`<span class="repo-ico gift-ico">${giftEmoji(n)}</span>`, n, ` +${v}`, 'gift:' + n)).join('')
    }</div></section>`;
    body.innerHTML = groups.map(([title, list]) => `<section class="repo-sec"><h4>${title}</h4><div class="repo-grid">${
      list.map((m) => repoItem(
        m.icon ? img(iconUrl(m.icon), 'repo-ico', m.base || m.name) : '<span class="repo-ico noicon"></span>',
        m.label || m.name, ` 需 ${num(m.need)}`, m.invKey || m.key)).join('')
    }</div></section>`).join('') + giftHTML;
    updateRepoCount();
  }

  function updateRepoCount() {
    const all = $$('#repoBody [data-repo]');
    const n = all.filter((i) => Number(i.value) > 0).length;
    $('#repoCount').textContent = `${n} / ${all.length} 项已填`;
  }

  function openRepo() { renderRepo(); $('#repo').classList.add('on'); }
  function closeRepo() { $('#repo').classList.remove('on'); renderResult(); }

  /* ---------------- 渲染：结果（网格卡片） ---------------- */
  function giftEmoji(name) {
    if (name.includes('超爱')) return '🏆';
    if (name.includes('3★最爱')) return '💎';
    if (name.includes('3★喜欢')) return '🎁';
    if (name.includes('2★最爱')) return '🎂';
    if (name.includes('2★喜欢')) return '🍬';
    return '🎀';
  }

  function matCard(m) {
    const ico = m.icon
      ? img(iconUrl(m.icon), 'cico', m.base)
      : '<span class="cico noicon" aria-hidden="true"></span>';
    return `<div class="mcard ${m.satisfied ? 'ok' : 'hasgap'}" data-card="${esc(m.key)}" tabindex="0">
      ${ico}
      ${m.kind === 'blueprint' ? `<i class="tier">${esc(m.rarity)}</i>` : ''}
      <span class="badge">${m.satisfied ? '已满足' : `×${num(m.gap)}`}</span>
      <span class="tip">
        <b>${esc(m.label)}</b>
        <span>需求 ${num(m.need)} · 持有 ${num(m.have)} · 缺口 ${num(m.gap)}</span>
        <span class="tipdim">最优刷取关卡：暂无数据</span>
        ${m.by && m.by.length > 1 ? `<span class="tipdim">${m.by.map((x) => esc(x.name) + ' ×' + x.n).join('　')}</span>` : ''}
      </span>
    </div>`;
  }

  const RARITY_ORDER = { '紫': 0, '金': 1, '蓝': 2, '白': 3 };
  let SYNTH = new Map();            // 合成卡片（强化珠/经验书按稀有度拆开）
  const byRarity = (a, b) => (RARITY_ORDER[a.rarity] ?? 9) - (RARITY_ORDER[b.rarity] ?? 9) || b.need - a.need;
  const byTierDesc = (a, b) => (parseInt(String(b.rarity).replace('T', ''), 10) || 0) - (parseInt(String(a.rarity).replace('T', ''), 10) || 0) || b.need - a.need;

  function renderResult() {
    const r = computeAll();
    LAST = r;
    if (!state.plan.length) {
      $('#result').innerHTML = '<div class="empty-big">先把角色加入上方的规划列表，这里会显示材料缺口</div>';
      $('#summary').textContent = '把角色加入规划后自动计算';
      return;
    }
    const rows = r.rows.rows;
    SYNTH = new Map();

    const bookInv = ['紫', '金', '蓝', '白'].map((k) => ({ k, n: Number(state.inv['book:' + k] || 0), exp: T.books[k].exp }));
    const bookExp = bookInv.reduce((a, b) => a + b.n * b.exp, 0);
    const expLeft = Math.max(0, r.exp - bookExp);

    const giftList = giftListOf();
    const giftExpHave = giftList.reduce((a, [n, v]) => a + (Number(state.inv['gift:' + n] || 0) * v), 0);
    const bondLeft = Math.max(0, r.bondExp - giftExpHave);

    /* ---------- 分组 ---------- */
    const bdNote = rows.filter((m) => m.kind === 'bd' || m.kind === 'note').sort(byRarity);
    const artifact = rows.filter((m) => m.kind === 'artifact').sort(byRarity);
    const secret = rows.filter((m) => m.kind === 'secretStone');
    const bp = rows.filter((m) => m.kind === 'blueprint').sort(byTierDesc);

    // 强化珠：按总经验拆成 4 种稀有度
    const stoneExpTotal = rows.filter((m) => m.kind === 'enhanceStone').reduce((a, b) => a + (b.expNeeded || 0), 0);
    const stoneCards = stoneExpTotal > 0 ? ['紫', '金', '蓝', '白'].map((k) => {
      const need = Math.ceil(stoneExpTotal / T.equip.stoneExp[k]);
      const key = `stone|${k}`;
      const have = Number(state.inv[key] || 0);
      const gap = Math.max(0, need - have);
      const m = { key, invKey: key, kind: 'enhanceStone', rarity: k, base: `${k}强化珠`, label: `${k}强化珠`,
                  name: `${k}强化珠`, need, have, gap, satisfied: gap === 0, icon: T.icons.enhanceStone[k] };
      SYNTH.set(key, m);
      return m;
    }) : [];

    // 经验书：按稀有度 4 档
    const bookCards = ['紫', '金', '蓝', '白'].map((k) => {
      const need = Math.ceil(r.exp / T.books[k].exp);
      const invKey = 'book:' + k;
      const have = Number(state.inv[invKey] || 0);
      const gap = Math.max(0, need - have);
      const key = `book|${k}`;
      const m = { key, invKey, kind: 'book', rarity: k, base: `${k}经验书`, label: `${k}经验书`,
                  name: `${k}经验书`, need, have, gap, satisfied: gap === 0, icon: T.icons.books[k] };
      SYNTH.set(key, m);
      return m;
    });

    const grid = (list) => `<div class="mgrid">${list.map(matCard).join('')}</div>`;
    const sub = (title, list) => list && list.length ? `<h4 class="sub">${title}</h4>${grid(list)}` : '';

    /* ---------- 资源总缺口条 ---------- */
    const bdGap = rows.filter((m) => m.kind === 'bd').reduce((a, b) => a + b.gap, 0);
    const stoneGap = stoneCards.reduce((a, b) => a + b.gap, 0);
    const resHTML = `<div class="res">
      <div class="rbar credit" data-card="credit" tabindex="0">
        <img class="rico" src="${iconUrl(T.icons?.res?.credit)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">
        <span class="rlab">信用点</span><b>${num(r.rows.credit.gap)}</b>
      </div>
      <div class="rbar bd">
        <img class="rico" src="${iconUrl(T.icons?.res?.bd)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">
        <span class="rlab">战术教育 BD</span><b>${num(bdGap)}</b>
      </div>
      <div class="rbar stone">
        <img class="rico" src="${iconUrl(T.icons?.res?.stone)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">
        <span class="rlab">强化珠（折算紫珠）</span><b>${num(stoneCards[0] ? stoneCards[0].gap : 0)}</b>
      </div>
      ${r.exp ? `<div class="rbar xp">
        <img class="rico" src="${iconUrl(T.icons?.res?.exp)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">
        <span class="rlab">角色经验</span><b>${num(r.exp)}</b></div>` : ''}
    </div>`;

    /* ---------- 礼物：紫礼(3★) / 金礼(2★) 各三档 ---------- */
    const t2 = GIFTS.filter((g) => g.tier === 2), t3 = GIFTS.filter((g) => g.tier === 3);
    const giftCard = (n, v, sample) => {
      const have = Number(state.inv['gift:' + n] || 0);
      const cnt = Math.ceil(bondLeft / v);
      const done = cnt <= 0;
      const ico = sample ? img(iconUrl(sample.icon), 'cico', sample.name)
        : '<span class="cico noicon" aria-hidden="true"></span>';
      return `<div class="mcard gift ${done ? 'ok' : 'hasgap'}" data-giftcard="${esc(n)}" tabindex="0">
        ${ico}
        <span class="badge">${done ? '已满足' : `<i>🙂</i>${num(cnt)}`}</span>
        <span class="tip"><b>${esc(n)}</b><span>单个 ${v} 好感 · 还需 ${num(bondLeft)}</span>
          <span class="tipdim">示例图标：${sample ? esc(sample.name) : '—'}</span>
          <span class="tipdim">已持有 ${num(have)} 个</span></span>
      </div>`;
    };
    const purpleGifts = [['3★喜欢礼物', 120], ['3★最爱礼物', 180], ['3★超爱礼物', 240]]
      .map(([n, v], i) => giftCard(n, v, t3[i % (t3.length || 1)]));
    const goldGifts = [['2★普通礼物', 20], ['2★喜欢礼物', 40], ['2★最爱礼物', 60]]
      .map(([n, v], i) => giftCard(n, v, t2[i % (t2.length || 1)]));

    const giftOptions = giftListOf().map(([n]) =>
      `<option value="${esc(n)}"${n === state.gift ? ' selected' : ''}>${esc(n)}</option>`).join('');

    const bondPerHTML = (r.per || []).filter((p) => p.bond && p.bond.exp > 0).map((p) => {
      const s = byId[p.id];
      const fs = favGifts(s);
      const best = fs[0];
      const n = best ? Math.ceil(p.bond.exp / best.value) : 0;
      return `<div class="brow">
        ${img(studentIcon(s.id), 'bava', s.name)}
        <div class="bmeta"><b>${esc(s.name)}</b><small>还需 ${num(p.bond.exp)} 好感</small></div>
        ${best
          ? `<span class="bgift" title="${esc(best.name)} +${best.value}">${img(itemIcon(best.icon), 'gimg', best.name)}<i>×${num(n)}</i></span>`
          : '<span class="opt off">无偏好数据</span>'}
        <span class="bwhy">${best ? `${best.beloved ? '超爱' : '最爱'} · ${esc(best.name)} +${best.value}` : ''}</span>
      </div>`;
    }).join('');

    const bondHTML = `<h3 class="bond">好感度礼物<small>独立模块，不计入材料缺口</small></h3>
      ${bondPerHTML ? `<div class="bpanel">${bondPerHTML}</div>` : ''}
      <div class="bondhead">
        <div class="hint">优先用上面对应的喜爱礼物最省；以下为通用档位折算，任选其一即可（OR）</div>
        <label class="giftsel">礼物折算
          <select id="gift">${giftOptions}</select></label>
      </div>
      <h4 class="sub">紫礼（3★）</h4><div class="mgrid gifts">${purpleGifts.join('')}</div>
      <h4 class="sub">金礼（2★）</h4><div class="mgrid gifts">${goldGifts.join('')}</div>
      <div class="concl" id="bondConcl">${bondConcl(bondLeft)}</div>`;

    const expHTML = `<h4 class="sub">经验书（按稀有度）</h4>${grid(bookCards)}
      <div class="box" style="margin-top:10px">
        <div class="kv"><span>还需经验</span><b>${num(r.exp)}</b></div>
        <div class="hint">以下为多种喂书方案，任选其一即可（OR）</div>
        <div class="plans" id="expPlans">${plansHTML(expLeft)}</div>
        <div class="subhint" id="expAlt">${altHTML(expLeft)}</div>
        <div class="concl" id="expConcl">${expConcl(expLeft)}</div>
      </div>`;

    const warnHTML = r.warnings.length ? `<div class="note">
      ${r.warnings.map((w) => `<div>${esc(w.msg)}</div>`).join('')}
    </div>` : '';

    $('#result').innerHTML = `
      <h3>技能材料<small>点击卡片填持有</small></h3>
      ${sub('战术教育 BD / 技术笔记（紫 → 白）', bdNote)}
      ${sub('古物（紫 → 白）', artifact)}
      <h3>装备</h3>
      ${sub('图纸（T 阶从高到低）', bp)}
      ${sub('强化珠（按稀有度换算）', stoneCards)}
      ${secret.length ? `<h3>升星 / 专精</h3>${grid(secret)}` : ''}
      <h3>角色经验<small>1→90 共 ${num(1249185)}</small></h3>
      ${expHTML}
      ${rows.length ? '<h3>资源总缺口</h3>' + resHTML : ''}
      ${bondHTML}
      ${warnHTML}`;

    $('#summary').textContent = `${state.plan.length} 名角色 · 材料 ${rows.length} 项 · 信用点 ${num(r.credit)}`;
  }

  /* ---------------- 库存弹层 ---------------- */
  let POP = null;

  function closePop() {
    if (POP) { POP.remove(); POP = null; }
  }

  function openPop(kind, key) {
    closePop();
    const r = LAST;
    if (!r) return;
    let title = '', need = 0, have = 0, gap = 0, iconHTML = '', attr = '';
    if (kind === 'gift') {
      const g = giftListOf().find(([n]) => n === key);
      if (!g) return;
      const cnt = Number(state.inv['gift:' + key] || 0);
      title = key;
      need = Math.ceil(Math.max(0, r.bondExp - giftListOf().reduce((a, [n, v]) => a + Number(state.inv['gift:' + n] || 0) * v, 0)) / g[1]);
      have = cnt;
      gap = Math.max(0, need - have);
      iconHTML = `<span class="cico gift-ico">${giftEmoji(key)}</span>`;
      attr = `data-gift="${esc(key)}"`;
    } else if (kind === 'credit') {
      title = '信用点';
      need = r.rows.credit.need; have = r.rows.credit.have; gap = r.rows.credit.gap;
      iconHTML = '<span class="cico glyph g-credit">币</span>';
      attr = 'data-inv="credit"';
    } else {
      const m = r.rows.rows.find((x) => x.key === key) || SYNTH.get(key);
      if (!m) return;
      title = m.label || m.name; need = m.need; have = m.have; gap = m.gap;
      iconHTML = m.icon ? img(iconUrl(m.icon), 'cico', m.base || m.name)
        : '<span class="cico noicon" aria-hidden="true"></span>';
      attr = `data-inv="${esc(m.invKey || key)}"`;
    }

    POP = document.createElement('div');
    POP.className = 'popup';
    POP.dataset.kind = kind;
    POP.dataset.key = key;
    POP.innerHTML = `<div class="pop-h">${iconHTML}<b>${esc(title)}</b>
        <button class="pop-x" data-pop-close aria-label="关闭">✕</button></div>
      <div class="pop-row"><span>需求 <b>${num(need)}</b></span><span>已有 <b class="pop-have">${num(have)}</b></span>
        <span>缺口 <b class="pop-gap">${num(gap)}</b></span></div>
      <label class="pop-inp"><span>持有</span>
        <input type="number" min="0" ${attr} value="${have || ''}" placeholder="0" inputmode="numeric"></label>
      <div class="pop-tip">最优刷取关卡：暂无数据</div>
      <div class="pop-acts">
        <button class="btn ghost" data-pop-close>取消</button>
        <button class="btn" data-pop-ok>确认</button>
      </div>`;
    document.body.appendChild(POP);
    const inp = POP.querySelector('input');
    if (inp) setTimeout(() => { inp.focus(); inp.select(); }, 30);
  }

  /** 把弹层里输入的数量写回库存 */
  function applyPop() {
    if (!POP) return;
    const inp = POP.querySelector('input');
    if (!inp) return;
    const v = Math.max(0, Number(inp.value) || 0);
    if (inp.dataset.gift) state.inv['gift:' + inp.dataset.gift] = v;
    else if (inp.dataset.inv) state.inv[inp.dataset.inv] = v;
    save();
    renderResult();
    closePop();
    toast('库存已更新');
  }

  /* ---------------- 文本导出 ---------------- */
  function buildText() {
    const r = computeAll();
    const L = ['蔚蓝档案 · 养成缺口', `角色：${state.plan.map((e) => byId[e.id].name).join('、')}`, ''];
    const push = (title, list) => {
      if (!list.length) return;
      L.push(`【${title}】`);
      for (const m of list) L.push(`${m.label} ×${m.need}${m.satisfied ? '（已满足）' : `（缺 ${m.gap}）`}`);
      L.push('');
    };
    push('技能材料', r.rows.rows.filter((m) => ['bd', 'note', 'artifact'].includes(m.kind)));
    push('神明文字', r.rows.rows.filter((m) => m.kind === 'secretStone'));
    push('装备', r.rows.rows.filter((m) => ['blueprint', 'enhanceStone'].includes(m.kind)));
    L.push(`【信用点】需 ${num(r.credit)}${r.rows.credit.satisfied ? '（已满足）' : `（缺 ${num(r.rows.credit.gap)}）`}`);
    if (r.exp) L.push(`\n【角色经验】还需 ${num(r.exp)}`, ...r.plans.map((p) => `  ${p.name}：${p.p ? `紫书×${p.p} ` : ''}${p.g ? `金书×${p.g}` : ''}`));
    if (r.bondExp) L.push(`\n【好感度】还需 ${num(r.bondExp)}`, ...r.gifts.map((g) => `  ${g.name} ×${g.count}`));
    return L.join('\n');
  }

  /* ---------------- 事件 ---------------- */
  function bind() {
    $('#q').addEventListener('input', (e) => { state.q = e.target.value; renderCandidates(); });

    $('#schools').addEventListener('click', (e) => {
      const b = e.target.closest('[data-school]');
      if (!b) return;
      state.school = b.dataset.school;
      $$('#schools .chip').forEach((c) => c.classList.toggle('on', c.dataset.school === state.school));
      renderCandidates();
    });
    $('#stars').addEventListener('click', (e) => {
      const b = e.target.closest('[data-star]');
      if (!b) return;
      state.star = b.dataset.star;
      $$('#stars .chip').forEach((c) => c.classList.toggle('on', c.dataset.star === state.star));
      renderCandidates();
    });

    $('#candidates').addEventListener('click', (e) => {
      const b = e.target.closest('[data-add]');
      if (!b) return;
      state.plan.push(mkEntry(Number(b.dataset.add)));
      renderCandidates(); renderPlan(); renderResult(); save();
    });

    $('#plan').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-act]');
      const card = e.target.closest('.card');
      if (!card) return;
      const id = Number(card.dataset.id);
      const e0 = state.plan.find((p) => p.id === id);
      if (!e0) return;
      if (btn) {
        const act = btn.dataset.act;
        if (act === 'del') state.plan = state.plan.filter((p) => p.id !== id);
        if (act === 'full') e0.tgt = fullCfg(byId[id]);
        if (act === 'same') e0.tgt = JSON.parse(JSON.stringify(e0.cur));
        renderCandidates(); renderPlan(); renderResult(); save();
        return;
      }
    });

    $('#plan').addEventListener('input', (e) => {
      const el = e.target;
      const card = el.closest('.card');
      if (!card) return;
      const e0 = state.plan.find((p) => p.id === Number(card.dataset.id));
      if (!e0) return;
      const side = el.dataset.side || 'cur';
      const t = el.dataset;
      if (t.f === 'skill') {
        e0[side].skill = el.value;
        const pv = el.parentElement.querySelector('.preview');
        const p = CALC.parseSkillNotation(el.value);
        pv.textContent = p ? CALC.formatSkillLevels(p) : '格式错误';
        pv.classList.toggle('bad', !p);
      } else if (t.f) {
        e0[side][t.f] = Number(el.value);
      } else if (t.eqTier !== undefined) {
        e0[side].equips[Number(t.eqTier)].tier = Number(el.value);
      } else if (t.eqLevel !== undefined) {
        e0[side].equips[Number(t.eqLevel)].level = Number(el.value);
      }
      renderResult(); save();
    });

    $('#plan').addEventListener('change', (e) => {
      const loveEl = e.target.closest('[data-love]');
      if (loveEl) {
        const en = state.plan.find((p) => p.id === Number(loveEl.dataset.love));
        if (en) { en.love = loveEl.checked; renderResult(); save(); }
        return;
      }
      if (e.target.tagName === 'SELECT') renderResult();
    });

    $('#result').addEventListener('input', (e) => {
      const bookEl = e.target.closest('[data-book]');
      if (bookEl) {
        state.inv['book:' + bookEl.dataset.book] = Number(bookEl.value) || 0;
        refreshExp(); save(); return;
      }
      const giftEl = e.target.closest('[data-gift]');
      if (giftEl) {
        state.inv['gift:' + giftEl.dataset.gift] = Number(giftEl.value) || 0;
        refreshBond(); save(); return;
      }
      const el = e.target.closest('[data-inv]');
      if (!el) return;
      state.inv[el.dataset.inv] = Number(el.value) || 0;
      const r = computeAll();
      // 只更新缺口，避免输入时失焦
      const row = el.closest('.mrow');
      const m = r.rows.rows.find((x) => x.key === el.dataset.inv) ||
                (el.dataset.inv === 'credit' ? r.rows.credit : null);
      if (m && row) {
        const cell = row.querySelector('.gap');
        if (cell) cell.textContent = m.satisfied ? '0' : num(m.gap);
        row.classList.toggle('ok', m.satisfied);
        const badge = row.querySelector('.okbadge');
        if (m.satisfied && !badge) {
          const b = document.createElement('span');
          b.className = 'okbadge';
          b.textContent = '已满足';
          row.querySelector('.mright').appendChild(b);
        } else if (!m.satisfied && badge) badge.remove();
      }
      save();
    });

    $('#result').addEventListener('click', (e) => {
      const p = e.target.closest('[data-peek]');
      if (p) {
        const src = p.parentElement.querySelector('.src');
        if (src) src.hidden = !src.hidden;
        return;
      }
      const card = e.target.closest('[data-card]');
      if (card) { openPop(card.dataset.card === 'credit' ? 'credit' : 'mat', card.dataset.card); return; }
      const gc = e.target.closest('[data-giftcard]');
      if (gc) { openPop('gift', gc.dataset.giftcard); return; }
    });

    // 弹层：确认 / 取消 / 点外部关闭
    document.addEventListener('click', (e) => {
      if (e.target.closest('[data-pop-ok]')) { applyPop(); return; }
      if (e.target.closest('[data-pop-close]')) { closePop(); return; }
      if (!POP) return;
      if (e.target.closest('.popup') || e.target.closest('[data-card]') || e.target.closest('[data-giftcard]')) return;
      closePop();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { closePop(); return; }
      if (e.key === 'Enter' && POP && e.target.closest && e.target.closest('.popup')) { e.preventDefault(); applyPop(); }
      if (!e.target || e.target.id !== 'gift') return;
    });

    // 礼物折算下拉（渲染在好感度模块里，用委托监听）
    $('#result').addEventListener('change', (e) => {
      if (e.target && e.target.id === 'gift') {
        state.gift = e.target.value;
        save(); renderResult();
      }
    });

    $('#btnCopy').addEventListener('click', async () => {
      const txt = buildText();
      try { await navigator.clipboard.writeText(txt); toast('已复制到剪贴板'); }
      catch { $('#ta').value = txt; $('#modal').classList.add('on'); }
    });
    $('#btnExport').addEventListener('click', () => {
      const blob = new Blob([JSON.stringify({ v: 1, plan: state.plan, inv: state.inv, gift: state.gift }, null, 1)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'ba-plan.json';
      a.click();
    });
    $('#btnImport').addEventListener('click', () => $('#modal').classList.add('on'));
    $('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal' || e.target.id === 'mClose') $('#modal').classList.remove('on'); });
    $('#mLoad').addEventListener('click', () => {
      try {
        const parsed = parseSave($('#ta').value);
        if (!parsed.plan.length) throw new Error('empty');
        state.plan = parsed.plan;
        state.inv = parsed.inv;
        $('#modal').classList.remove('on');
        renderCandidates(); renderPlan(); renderResult(); save();
        toast(`已导入 ${parsed.plan.length} 个角色、${Object.keys(parsed.inv).length} 条库存`);
      } catch { toast('未识别的存档格式，已保持原数据不变'); }
    });

    const themeBtn = $('#themeBtn');
    if (themeBtn) themeBtn.addEventListener('click', () => {
      setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
    });
    const foldBtn = $('#foldBtn');
    if (foldBtn) foldBtn.addEventListener('click', () => {
      const on = document.body.classList.toggle('folded');
      foldBtn.textContent = on ? '展开配置 ▾' : '收起配置 ▴';
    });

    const moreBtn = $('#moreBtn');
    if (moreBtn) moreBtn.addEventListener('click', () => {
      const open = $('#candidates').classList.toggle('expanded');
      moreBtn.textContent = open ? '收起列表 ▴' : `展开全部 ${S.length} 人 ▾`;
    });

    const repoBtn = $('#btnRepo');
    if (repoBtn) repoBtn.addEventListener('click', openRepo);
    const repoDone = $('#repoDone');
    if (repoDone) repoDone.addEventListener('click', closeRepo);
    const repoClear = $('#repoClear');
    if (repoClear) repoClear.addEventListener('click', () => {
      $$('#repoBody [data-repo]').forEach((i) => { state.inv[i.dataset.repo] = 0; i.value = ''; });
      save(); updateRepoCount();
    });
    const repoBody = $('#repoBody');
    if (repoBody) repoBody.addEventListener('input', (e) => {
      const el = e.target.closest('[data-repo]');
      if (!el) return;
      state.inv[el.dataset.repo] = Number(el.value) || 0;
      save(); updateRepoCount();
    });
  }

  /* 兼容多种存档结构：本项目导出 / {plan,inv} / {students:[...]} / {id:{...}} */
  function parseSave(text) {
    const d = JSON.parse(text);
    const out = { plan: [], inv: {} };
    const pickId = (e) => Number(e.id ?? e.studentId ?? e.student_id ?? e.Id ?? e.characterId);
    const pickCfg = (e, k1, k2) => e[k1] || e[k2] || {};

    const addOne = (raw) => {
      const id = pickId(raw);
      if (!byId[id]) return false;
      const base = mkEntry(id);
      const cur = pickCfg(raw, 'current', 'cur');
      const tgt = pickCfg(raw, 'target', 'tgt');
      Object.assign(base.cur, cur, { skill: cur.skill ?? base.cur.skill });
      Object.assign(base.tgt, tgt, { skill: tgt.skill ?? base.tgt.skill });
      base.cur.skill = String(base.cur.skill);
      base.tgt.skill = String(base.tgt.skill);
      base.love = !!(raw.love || raw.loveItem);
      out.plan.push(base);
      return true;
    };

    if (Array.isArray(d.plan)) d.plan.forEach(addOne);
    else if (Array.isArray(d.students)) d.students.forEach(addOne);
    else if (Array.isArray(d.characters)) d.characters.forEach(addOne);
    else if (d && typeof d === 'object') {
      for (const [k, v] of Object.entries(d)) {
        if (/^\d+$/.test(k) && v && typeof v === 'object') addOne({ id: k, ...v });
      }
    }
    if (d.inv && typeof d.inv === 'object') Object.assign(out.inv, d.inv);
    if (d.inventory && typeof d.inventory === 'object') Object.assign(out.inv, d.inventory);
    return out;
  }

  function setTheme(t) {
    document.documentElement.dataset.theme = t;
    state.theme = t;
    try { localStorage.setItem('ba-theme', t); } catch {}
    const b = $('#themeBtn');
    if (b) b.textContent = t === 'dark' ? '☀️ 日间' : '🌙 夜间';
  }

  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 1600);
  }

  function save() {
    try { localStorage.setItem('ba-calc', JSON.stringify({ plan: state.plan, inv: state.inv, gift: state.gift })); } catch {}
  }
  function load() {
    try {
      const d = JSON.parse(localStorage.getItem('ba-calc') || 'null');
      if (!d) return;
      state.plan = (d.plan || []).filter((x) => byId[x.id]);
      state.inv = d.inv || {};
      state.gift = d.gift || state.gift;
    } catch {}
  }

  /* ---------------- 初始化 ---------------- */
  function init() {
    $('#schools').innerHTML = ['all', ...SCHOOLS]
      .map((s) => `<button class="chip${s === 'all' ? ' on' : ''}" data-school="${s}">${s === 'all' ? '全部学校' : s}</button>`).join('');
    $('#stars').innerHTML = ['all', '3', '2', '1']
      .map((s) => `<button class="chip${s === 'all' ? ' on' : ''}" data-star="${s}">${s === 'all' ? '全部星级' : s + '★'}</button>`).join('');
    load();
    let theme = state.theme;
    try { theme = theme || localStorage.getItem('ba-theme'); } catch {}
    if (!theme) theme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
    setTheme(theme);

    bind();
    renderCandidates(); renderPlan(); renderResult();

    // PWA：只有 http(s) 下才注册（file:// 双击打开时自动跳过）
    if ('serviceWorker' in navigator && typeof location !== 'undefined' && location.protocol.startsWith('http')) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  }

  document.addEventListener('DOMContentLoaded', init);
})();
