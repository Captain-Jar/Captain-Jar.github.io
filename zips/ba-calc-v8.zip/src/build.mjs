import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const R = (p) => path.join(__dirname, p);

const studentsFile = JSON.parse(fs.readFileSync(R('data/students.json'), 'utf8'));
const giftsFile = JSON.parse(fs.readFileSync(R('data/gifts.json'), 'utf8'));
const global = JSON.parse(fs.readFileSync(R('data/global.json'), 'utf8'));
const calcSrc = fs.readFileSync(R('calc.js'), 'utf8');
const coreSrc = fs.readFileSync(R('core.js'), 'utf8');
const css = fs.readFileSync(R('ui/app.css'), 'utf8');
const app = fs.readFileSync(R('ui/app.js'), 'utf8');

// ESM -> 单文件 IIFE（file:// 下不能用 module）
const calcBody = calcSrc.replace(/^export\s+/gm, '');
const coreBody = coreSrc
  .replace(/import\s*\{[\s\S]*?\}\s*from\s*['"]\.\/calc\.js['"];?/, '')
  .replace(/^export\s+/gm, '');

const calcWrap = `const CALC = (function(){
${calcBody}
${coreBody}
const core = createCore({ students: DATA.students, global: DATA.global });
return {
  parseSkillNotation, formatSkillLevels, calcSkillDelta, calcStarDelta, calcEquipDelta,
  calcExpDelta, calcBondDelta, applyInventory, mergeResults, toText,
  createCore, core,
  calculateMaterials: core.calculateMaterials,
  calculateMany: core.calculateMany
};
})();
window.BACalc = CALC.core;`;

const dataJSON = JSON.stringify({
  students: studentsFile.students || studentsFile,
  global,
  gifts: giftsFile.gifts || [],
}).replace(/</g, '\\u003c');

const count = (studentsFile.students || studentsFile).length;

const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>蔚蓝档案 · 养成差量计算器</title>
<meta name="theme-color" content="#128afa">
<link rel="manifest" href="manifest.json">
<link rel="icon" href="icon.svg" type="image/svg+xml">
<style>${css}</style>
</head>
<body>
<header class="top">
  <h1>蔚蓝档案 · 养成差量计算器</h1>
  <div class="sub" id="summary"></div>
  <div class="topbar">
    <button id="btnCopy" class="tbtn" title="复制为纯文本">📋 复制</button>
    <button id="btnExport" class="tbtn" title="导出配置 JSON">💾 导出</button>
    <button id="btnImport" class="tbtn" title="导入配置 JSON">📥 导入</button>
    <span class="tsep"></span>
    <button id="foldBtn" class="tbtn" title="折叠配置区">▴ 收起</button>
    <button id="themeBtn" class="tbtn" title="切换夜间模式">🌙 夜间</button>
  </div>
</header>
<main>
  <section class="picker">
    <div class="tools">
      <input id="q" type="search" placeholder="搜角色：中文名 / 日文名 / 学校（${count} 名可选）">
      <div id="schools" class="chips"></div>
      <div id="stars" class="chips"></div>
    </div>
    <div id="candidates" class="cands"></div>
  </section>

  <section id="plan" class="plan"></section>

  <section class="resultbar">
    <div class="rb-title">
      <h2>缺口汇总</h2>
      <div class="tipsub">* 点击下方材料卡片即可填写已有库存</div>
    </div>
  </section>

  <section id="result" class="result"></section>
</main>

<div id="modal" class="modal">
  <div class="box">
    <h3>粘贴 / 编辑配置 JSON</h3>
    <textarea id="ta" placeholder='{"plan":[...],"inv":{}}'></textarea>
    <div class="row"><button id="mClose" class="btn ghost">关闭</button><button id="mLoad" class="btn">载入</button></div>
  </div>
</div>

<script id="data" type="application/json">${dataJSON}</script>
<script>window.DATA = JSON.parse(document.getElementById('data').textContent);</script>
<script>${calcWrap}</script>
<script>${app}</script>
</body>
</html>
`;

fs.mkdirSync(R('dist'), { recursive: true });
fs.writeFileSync(R('dist/index.html'), html, 'utf8');
console.log('dist/index.html', (html.length / 1024).toFixed(0), 'KB | students', count);

/* ---------- PWA：manifest / service worker / icon ---------- */
const manifest = {
  name: '蔚蓝档案 · 养成差量计算器',
  short_name: 'BA计算器',
  start_url: './index.html',
  scope: './',
  display: 'standalone',
  background_color: '#f4f6f9',
  theme_color: '#128afa',
  icons: [
    { src: 'icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' },
  ],
};
fs.writeFileSync(R('dist/manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');

const icon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
<stop offset="0" stop-color="#5db6ff"/><stop offset="1" stop-color="#128afa"/></linearGradient></defs>
<rect width="192" height="192" rx="44" fill="url(#g)"/>
<path d="M96 34l14 32 34 4-25 24 7 34-30-17-30 17 7-34-25-24 34-4z" fill="#fff" opacity=".95"/>
<rect x="56" y="132" width="80" height="12" rx="6" fill="#fff" opacity=".85"/>
</svg>`;
fs.writeFileSync(R('dist/icon.svg'), icon, 'utf8');

const sw = `/* 蔚蓝档案计算器 · 离线缓存 */
const CACHE = 'ba-calc-v5';
const ASSETS = ['./', './index.html', './manifest.json', './icon.svg'];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;           // CDN 图片不拦截
  e.respondWith(
    caches.match(req).then((hit) => hit || fetch(req).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {});
      return res;
    }).catch(() => caches.match('./index.html')))
  );
});
`;
fs.writeFileSync(R('dist/sw.js'), sw, 'utf8');
console.log('dist/manifest.json + sw.js + icon.svg 写出');

const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
fs.writeFileSync(R('dist/_check.js'), scripts.join('\n;\n'), 'utf8');
