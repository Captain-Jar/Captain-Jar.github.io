/**
 * 蔚蓝档案 养成差量计算引擎（纯函数，无 DOM 依赖）
 * ------------------------------------------------------------
 * 数据约定：
 *   student.skillEx[i]     -> { from: 1..4, to: 2..5, cost: [ {id,kind,rarity,base,n} ] }
 *   student.skillNormal[i] -> { from: 2..9, to: 3..10, cost: [...] }   // 8 段，Lv2→3 … Lv9→10
 *   Lv1→2 是特例：只扣 BD + 古物，不扣技术笔记（数值见 global.skillLv2Cost）
 *
 * 统一返回：
 *   { materials:[{key,kind,school,rarity,base,label,n}], credit, warnings:[{code,msg}] }
 */

export const KIND_CN = { bd: '战术教育光盘', note: '技术笔记', artifact: '古物', secretStone: '神明文字' };

/** 材料类别名优先取数据（global.kindLabels），没有才用内置兜底字符串 */
const kindLabel = (tables, kind) => tables?.kindLabels?.[kind] || KIND_CN[kind] || kind;

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

function bucket() {
  return { materials: new Map(), credit: 0, warnings: [] };
}

function addMat(b, student, c, n, label) {
  const key = `${c.kind}|${student.school}|${c.rarity}|${c.base}`;
  const cur = b.materials.get(key);
  if (cur) { cur.n += n; return; }
  b.materials.set(key, {
    key, kind: c.kind, school: student.school, schoolCn: student.schoolCn,
    rarity: c.rarity, base: c.base, n, icon: c.icon || null,
    label: label || labelOf(c.kind, student.schoolCn, c.rarity, c.base),
  });
}

function labelOf(kind, schoolCn, rarity, base) {
  // 类别名与古物名全部来自数据（base 由 students.json 提供），这里只做拼接
  if (kind === 'artifact') return `${schoolCn} ${base} ${rarity}`;
  return `${schoolCn} ${rarity}${base}`;
}

function finish(b) {
  return {
    materials: [...b.materials.values()].sort((x, y) => y.n - x.n || x.label.localeCompare(y.label)),
    credit: b.credit,
    warnings: b.warnings,
  };
}

/** 合并多个角色的结果（批量汇总用） */
export function mergeResults(list) {
  const out = bucket();
  for (const r of list) {
    for (const m of r.materials) {
      const cur = out.materials.get(m.key);
      if (cur) cur.n += m.n;
      else out.materials.set(m.key, { ...m });
    }
    out.credit += r.credit;
    out.warnings.push(...(r.warnings || []));
  }
  // 去重告警
  const seen = new Set();
  out.warnings = out.warnings.filter((w) => (seen.has(w.code + w.msg) ? false : (seen.add(w.code + w.msg), true)));
  return finish(out);
}

/* ------------------------------------------------------------------ */
/* 技能简写解析：'7' -> 5777 / 'm' -> 5MMM / '57m' -> 57MM            */
/* ------------------------------------------------------------------ */
export function parseSkillNotation(input) {
  const s = String(input ?? '').trim().toLowerCase().replace(/\s/g, '');
  if (!s) return null;
  if (!/^[0-9m]{1,4}$/.test(s)) return null;
  const nums = [...s].map((c) => (c === 'm' ? 10 : Number(c)));
  if (nums.length === 1) {
    const v = nums[0];
    return { ex: clamp(v, 1, 5), basic: clamp(v, 1, 10), enhance: clamp(v, 1, 10), sub: clamp(v, 1, 10) };
  }
  const arr = nums.slice();
  while (arr.length < 4) arr.push(10);
  return { ex: clamp(arr[0], 1, 5), basic: clamp(arr[1], 1, 10), enhance: clamp(arr[2], 1, 10), sub: clamp(arr[3], 1, 10) };
}

export function formatSkillLevels(lv) {
  const f = (n) => (n >= 10 ? 'M' : String(n));
  return `${lv.ex}${f(lv.basic)}${f(lv.enhance)}${f(lv.sub)}`;
}

/* ------------------------------------------------------------------ */
/* 1. 技能差量                                                         */
/* ------------------------------------------------------------------ */
export function calcSkillDelta(student, current, target, tables) {
  const b = bucket();
  const tracks = [
    { key: 'ex', rows: student.skillEx, cn: 'EX' },
    { key: 'basic', rows: student.skillNormal, cn: '基础' },
    { key: 'enhance', rows: student.skillNormal, cn: '强化' },
    { key: 'sub', rows: student.skillNormal, cn: '子技能' },
  ];
  let levelsGained = 0;

  for (const t of tracks) {
    const cur = clamp(Number(current[t.key]) || 1, 1, 10);
    const tgt = clamp(Number(target[t.key]) || 1, 1, 10);
    if (tgt <= cur) continue;
    levelsGained += tgt - cur;

    if (t.key !== 'ex' && cur < 2 && tgt >= 2) {
      const lv2 = tables?.skillLv2Cost;
      if (lv2 && lv2.bd && lv2.artifact) {
        const arts = (student.skillEx?.[0]?.cost || []).filter((c) => c.kind === 'artifact');
        const art = arts.find((c) => c.rarity === '白') || arts[0];
        addMat(b, student, { kind: 'bd', rarity: lv2.bd.rarity, base: kindLabel(tables, 'bd') }, lv2.bd.n);
        if (art) addMat(b, student, { kind: 'artifact', rarity: lv2.artifact.rarity || art.rarity, base: art.base }, lv2.artifact.n);
        b.credit += lv2.credit ?? 0;
      }
    }
    for (const row of t.rows) {
      if (row.to > cur && row.to <= tgt) {
        for (const c of row.cost) addMat(b, student, c, c.n);
      }
    }
  }
  return finish(b);
}

/* ------------------------------------------------------------------ */
/* 2. 神明文字（升星 / 专精）                                          */
/* ------------------------------------------------------------------ */
export function calcStarDelta(student, currentStar, targetStar, tables) {
  const b = bucket();
  let cur = clamp(Number(currentStar) || student.initialStar, 1, 6);
  const tgt = clamp(Number(targetStar) || 1, 1, 6);
  if (cur < student.initialStar) {
    b.warnings.push({ code: 'STAR_BELOW_INITIAL', msg: `当前星级低于初始星级，已按初始 ${student.initialStar}★ 计算` });
    cur = student.initialStar;
  }
  let n = 0;
  for (let s = cur + 1; s <= tgt; s++) n += tables?.star?.[String(s)] ?? 0;
  if (n > 0) {
    b.materials.set(`secretStone|${student.school}|-|神明文字`, {
      key: `secretStone|${student.school}|-|神明文字`, kind: 'secretStone',
      school: student.school, schoolCn: student.schoolCn, rarity: '-', base: '神明文字', n,
      icon: tables?.icons?.secretStone || null,
      label: `${student.name} 神明文字`, initialStar: student.initialStar,
    });
    b.credit += (tgt - cur) * (tables?.credit?.perStarStep ?? 0);
  }
  return finish(b);
}

/* ------------------------------------------------------------------ */
/* 3. 装备（图纸 / 强化珠 分开；强化走“经验值 → 珠子”模型）             */
/* ------------------------------------------------------------------ */
export function calcEquipDelta(student, currentEquips, targetEquips, tables) {
  const b = bucket();
  const eq = tables?.equip ?? {};
  const stoneTier = '紫';
  const stoneExp = eq?.stoneExp?.[stoneTier] ?? 5760;
  const cum = (n) => {
    let s = 0;
    for (let i = 1; i <= n; i++) s += eq?.expPerLevel?.[String(i)] ?? 0;
    return s;
  };
  const fullTier = cum(9);
  let needExp = 0;

  for (let i = 0; i < student.equipment.length; i++) {
    const slot = student.equipment[i];
    const c = currentEquips[i] || { tier: 1, level: 1 };
    const t = targetEquips[i] || c;
    const ct = clamp(Number(c.tier) || 1, 1, 10);
    const tt = clamp(Number(t.tier) || 1, 1, 10);
    const cl = clamp(Number(c.level) || 1, 1, 10);
    const tl = clamp(Number(t.level) || 1, 1, 10);

    // 图纸：按“主图纸 + 副图纸”逐阶展开
    for (let tier = ct + 1; tier <= tt; tier++) {
      for (const step of eq?.blueprintSteps?.[String(tier)] ?? []) {
        const bpIcon = tables?.icons?.blueprintTier?.[String(step.t)] || tables?.icons?.blueprintTier?.['8'] || null;
        addMat(b, student, { kind: 'blueprint', rarity: `T${step.t}`, base: slot.slotCn, icon: bpIcon }, step.n,
               `${slot.slotCn} T${step.t} 图纸`);
      }
    }
    // 强化经验：同阶只算等级差；跨阶 = 补满当前阶 + 中间整阶 + 目标阶到 tl
    if (tt === ct) needExp += cum(tl - 1) - cum(cl - 1);
    else needExp += (fullTier - cum(cl - 1)) + (tt - ct - 1) * fullTier + cum(tl - 1);
  }

  if (needExp > 0) {
    const stones = Math.ceil(needExp / stoneExp);
    b.materials.set('enhanceStone|-|-|强化珠', {
      key: 'enhanceStone|-|-|强化珠', kind: 'enhanceStone', school: '-', schoolCn: '-',
      rarity: stoneTier, base: '强化珠', n: stones,
      icon: tables?.icons?.enhanceStone?.[stoneTier] || null,
      label: `${stoneTier}强化珠`, expNeeded: needExp,
    });
    b.credit += needExp * (eq?.creditPerExp ?? 0);
  }
  return finish(b);
}

/* ------------------------------------------------------------------ */
/* 4. 角色等级经验 + 经验书方案 + 信用点                                */
/* ------------------------------------------------------------------ */
export function calcExpDelta(currentLevel, targetLevel, tables) {
  const b = bucket();
  const cur = clamp(Number(currentLevel) || 1, 1, 90);
  const tgt = clamp(Number(targetLevel) || 1, 1, 90);
  let exp = 0;
  const table = tables?.exp?.table ?? [];
  for (let lv = cur; lv < tgt; lv++) exp += table[lv - 1] ?? 0;

  const rate = tables?.credit?.perExpPoint ?? 0;
  b.credit += exp * rate;

  const purple = tables?.books?.['紫']?.exp ?? 10000;
  const gold = tables?.books?.['金']?.exp ?? 2000;
  const plans = [];
  if (exp > 0) {
    const p1 = Math.ceil(exp / purple);
    plans.push({ name: '全紫书', 紫: p1, 金: 0, overflow: p1 * purple - exp });
    const p2 = Math.max(0, Math.floor(exp / purple) - 1);
    const rest = exp - p2 * purple;
    const g2 = Math.ceil(rest / gold);
    plans.push({ name: '紫+金混合', 紫: p2, 金: g2, overflow: p2 * purple + g2 * gold - exp });
    const g3 = Math.ceil(exp / gold);
    plans.push({ name: '全金书', 紫: 0, 金: g3, overflow: g3 * gold - exp });
  }
  return { ...finish(b), exp, plans };
}

/* ------------------------------------------------------------------ */
/* 5. 好感度（独立模块，礼物不计入主材料）                              */
/* ------------------------------------------------------------------ */
export function calcBondDelta(currentBond, targetBond, tables, giftName) {
  const b = bucket();
  const cur = clamp(Number(currentBond) || 1, 1, 100);
  const tgt = clamp(Number(targetBond) || 1, 1, 100);
  let exp = 0;
  const table = tables?.bond?.table ?? [];
  for (let lv = cur; lv < tgt; lv++) exp += table[lv - 1] ?? 0;

  const gifts = Object.entries(tables?.gifts ?? {})
    .filter(([k]) => typeof tables.gifts[k] === 'number')
    .map(([name, value]) => ({ name, value, count: value > 0 ? Math.ceil(exp / value) : 0 }));
  const picked = giftName ? gifts.find((o) => o.name === giftName) ?? null : gifts[gifts.length - 1] ?? null;
  return { ...finish(b), exp, gifts, picked };
}

/* ------------------------------------------------------------------ */
/* 库存对比：需求 / 持有 / 缺口                                         */
/* ------------------------------------------------------------------ */
export function applyInventory(demand, inventory = {}) {
  const rows = demand.materials.map((m) => {
    const have = Number(inventory[m.key] ?? 0) || 0;
    const gap = Math.max(0, m.n - have);
    return { ...m, need: m.n, have, gap, satisfied: gap === 0 };
  });
  const needCredit = demand.credit ?? 0;
  const haveCredit = Number(inventory['credit'] ?? 0) || 0;
  return {
    rows,
    credit: { need: needCredit, have: haveCredit, gap: Math.max(0, needCredit - haveCredit), satisfied: needCredit <= haveCredit },
    warnings: demand.warnings ?? [],
  };
}

/* ------------------------------------------------------------------ */
/* 纯文本导出                                                          */
/* ------------------------------------------------------------------ */
export function toText(demand, title = '材料清单') {
  const lines = [title, `信用点：${demand.credit.toLocaleString()}`];
  for (const m of demand.materials) lines.push(`${m.label} ×${m.n}`);
  return lines.join('\n');
}
