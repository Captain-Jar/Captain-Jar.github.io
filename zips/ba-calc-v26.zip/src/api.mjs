/**
 * Node 端开箱即用的入口：读本地 JSON，导出一个已绑定数据的 core
 *
 *   import { calculateMaterials } from './api.mjs'
 *   const r = calculateMaterials(10000, { star: 3, skill: '5777' }, { star: 6, skill: '5MMM' })
 *
 *   import { calculateMany } from './api.mjs'
 *   const all = calculateMany([{ studentId: 10000, current: {...}, target: {...} }])
 */
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createCore } from './core.js';

const dir = path.dirname(fileURLToPath(import.meta.url));
const readJSON = (p) => JSON.parse(readFileSync(path.join(dir, p), 'utf8'));

const studentsFile = readJSON('data/students.json');
const globalFile = readJSON('data/global.json');

export const core = createCore({
  students: studentsFile.students || studentsFile,
  global: globalFile,
});

export const calculateMaterials = core.calculateMaterials;
export const calculateMany = core.calculateMany;
export const students = core.students;
export const globalTable = globalFile;
export default core;
