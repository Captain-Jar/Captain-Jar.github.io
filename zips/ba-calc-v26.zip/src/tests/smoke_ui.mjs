/**
 * UI 冒烟测试：用最小 DOM 垫片跑一遍 dist/index.html 里的内联脚本，
 * 验证 init 不报错、候选列表与汇总区确实被渲染。
 * 运行：node tests/smoke_ui.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const R = (p) => path.join(__dirname, '..', p);

// 开发目录（dist/index.html）和解压后的目录（根目录 index.html）都能跑
const htmlPath = [R('dist/index.html'), path.join(__dirname, '..', '..', 'index.html')]
  .find((p) => fs.existsSync(p));
assert.ok(htmlPath, '找不到 index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
const dataJSON = html.match(/<script id="data" type="application\/json">([\s\S]*?)<\/script>/)[1];

function el(id) {
  const e = {
    id, innerHTML: '', textContent: '', value: '', hidden: false,
    dataset: {}, classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    style: {}, children: [], _on: {},
    addEventListener(t, fn) { (e._on[t] = e._on[t] || []).push(fn); },
    removeEventListener() {}, appendChild() {}, remove() {},
    querySelector: () => null, querySelectorAll: () => [],
    closest: () => null, click() {},
  };
  return e;
}

const nodes = new Map();
const document = {
  documentElement: { dataset: {} },
  body: { classList: { add() {}, remove() {}, toggle: () => false, contains: () => false }, appendChild() {} },
  getElementById(id) { if (!nodes.has(id)) nodes.set(id, el(id)); return nodes.get(id); },
  querySelector(sel) { return sel && sel.startsWith('#') ? document.getElementById(sel.slice(1)) : null; },
  querySelectorAll: () => [],
  addEventListener(type, fn) { if (type === 'DOMContentLoaded') document.__ready = fn; },
  createElement: () => el('tmp'),
  body: { appendChild() {} },
};

const sandbox = {
  console, document, navigator: { clipboard: { writeText: async () => {} } },
  localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  URL: { createObjectURL: () => 'blob:' }, Blob: class {},
  setTimeout, JSON, Math, Number, String, Object, Array, Set, Map, Date, isNaN, parseInt, parseFloat,
};
sandbox.window = sandbox;

const ctx = vm.createContext(sandbox);
document.getElementById('data').textContent = dataJSON;
for (const s of scripts) vm.runInContext(s, ctx, { filename: 'inline.js' });

// 触发 DOMContentLoaded
assert.ok(typeof document.__ready === 'function', 'init 必须注册在 DOMContentLoaded');
document.__ready();

const cands = document.getElementById('candidates').innerHTML;
const plan = document.getElementById('plan').innerHTML;
const result = document.getElementById('result').innerHTML;
const summary = document.getElementById('summary').textContent;

console.log('候选区长度', cands.length, '| 角色数', (cands.match(/data-add=/g) || []).length);
console.log('规划区:', plan.slice(0, 40));
console.log('汇总区长度', result.length, '| summary:', summary);

assert.ok(cands.includes('爱露'), '候选列表应包含角色');
assert.ok((cands.match(/data-add=/g) || []).length >= 18, '18 名角色都应可选');
assert.ok(plan.includes('还没有角色'), '初始规划区应显示空状态');
assert.ok(result.includes('先把角色加入') || result.includes('好感度'), '空状态应有引导文案');
assert.ok(result.includes('暂无') || result.includes('还没有') || true);

// 直接验证计算内核在浏览器上下文里也正常（const 不会挂到 global，用求值取）
const CALC = vm.runInContext('CALC', ctx);
const DATA = vm.runInContext('DATA', ctx);
assert.ok(CALC && CALC.calcSkillDelta, 'CALC 必须可用');
const aru = DATA.students.find((s) => s.id === 10000);
const d = CALC.calcSkillDelta(aru, { ex: 5, basic: 7, enhance: 7, sub: 7 }, { ex: 5, basic: 10, enhance: 10, sub: 10 }, DATA.global);
console.log('爱露 777→MMM 材料行数', d.materials.length, '|', d.materials.map((m) => `${m.label}×${m.n}`).join(' / '));
assert.equal(d.materials.length, 5);

/* ---- 交互流程：加入角色 → 目标全满 → 汇总出材料 ---- */
const fire = (id, type, ev) => (document.getElementById(id)._on[type] || [])[0](ev);
fire('candidates', 'click', { target: { closest: (sel) => (sel === '[data-add]' ? { dataset: { add: '10000' } } : null) } });
assert.ok(document.getElementById('plan').innerHTML.includes('爱露'), '点击候选后规划区应出现该角色');

const stubCard = { dataset: { id: '10000' } };
fire('plan', 'click', { target: { closest: (sel) =>
  sel === '[data-act]' ? { dataset: { act: 'full' } } : (sel === '.card' ? stubCard : null) } });

/* ---- 多角色：每个角色各有自己的搭配栏 ---- */
fire('candidates', 'click', { target: { closest: (sel) => (sel === '[data-add]' ? { dataset: { add: '10024' } } : null) } });
fire('plan', 'click', { target: { closest: (sel) =>
  sel === '[data-act]' ? { dataset: { act: 'full' } } : (sel === '.card' ? { dataset: { id: '10024' } } : null) } });
const out2 = document.getElementById('result').innerHTML;
const bookMixers = (out2.match(/· 经验书搭配/g) || []).length;
const giftMixers = (out2.match(/· 礼物搭配/g) || []).length;
console.log('多角色搭配栏：经验书', bookMixers, '礼物', giftMixers);
assert.ok(bookMixers >= 2, '两个角色应各有一个经验书搭配栏');
assert.ok(giftMixers >= 2, '两个角色应各有一个礼物搭配栏');

/* ---- 新增特性 ---- */
assert.ok(['dark', 'light'].includes(document.documentElement.dataset.theme), '主题应被初始化');
const planHTML = document.getElementById('plan').innerHTML;
assert.ok(!planHTML.includes('class="advice"'), '角色卡已去掉养成建议简介');
assert.ok(planHTML.includes('data-love='), '有爱用品的角色应出现开关');
assert.ok(planHTML.includes('favico'), '角色卡应展示最爱礼物图标');

const out = document.getElementById('result').innerHTML;
const plain = out.replace(/<[^>]+>/g, ' ');
console.log('汇总区含材料行：', out.includes('技术笔记'), '| 含信用点：', out.includes('信用点'),
            '| 含好感度：', out.includes('好感度'));
assert.ok(out.includes('技术笔记'), '目标全满后应输出技能材料');
assert.ok(out.includes('信用点'), '应输出信用点行');
assert.ok(out.includes('好感度'), '好感度应为独立模块');

/* ---- 新增：OR 提示 / 库存入口 / 结论行 / 无黄色警告 ---- */
assert.equal((out.match(/任选其一即可（OR）/g) || []).length, 0, '已删除 OR 方案框');
assert.ok(out.includes('data-card="book|紫"'), '经验书应渲染成卡片');
assert.ok(out.includes('data-card="stone|紫"'), '强化珠应按稀有度拆成卡片');
assert.ok(out.includes('data-giftcard='), '礼物应渲染成网格卡片');
assert.ok(out.includes('class="mcard'), '材料应渲染成网格卡片');
assert.ok(out.includes('class="creditbox"') && out.includes('总消耗'), '应有信用点总消耗面板');
assert.ok(out.includes('class="crow c-'), '信用点应列出消耗去向（带颜色分类）');
assert.ok(!out.includes('技能 Lv1→2'), '技能行不再写 Lv1→2');
assert.ok(!out.includes('rbar'), '旧资源条已删除');
assert.ok(!out.includes('库存抵扣后还需'), '好感结论行已删除');
assert.ok(!out.includes('待核实'), '不应再出现“待核实”字样');

/* ---- 布局调整：全局按钮在顶栏、礼物折算在好感度模块 ---- */
assert.ok(html.includes('id="btnCopy"') && html.includes('id="btnExport"') && html.includes('id="btnImport"'),
  '复制/导出/导入应在顶栏');
assert.ok(!html.includes('点击下方材料卡片即可填写已有库存'), '已去掉旧的缺口汇总提示栏');
assert.ok(!out.includes('最优刷取关卡'), '已去掉刷取关卡提示');
assert.ok(out.includes('class="brow"'), '好感度区应展示按角色的最爱礼物行');
assert.ok(out.includes('gval') && /\+2\d\d/.test(out), '礼物卡应显示好感数值');
assert.ok(out.includes('class="mixer"') && out.includes('data-mix='), '强化珠/经验书应有自己搭配');
assert.ok(out.includes('默认全用最高级'), '混搭默认全用最高级');

/* ---- 公共素材必须有真图，不能是文字色块 ---- */
assert.ok(out.includes('images/equipment/icon/equipment_icon_exp'), '强化珠应使用真实图标');
assert.ok(out.includes('item_icon_secretstone'), '神明文字应使用真实图标');
assert.ok(/images\/equipment\/icon\/equipment_icon_\w+_tier\d+_piece/.test(out), '图纸应使用具体部位的图纸图');
assert.ok(!/>图</.test(out) && !/>神</.test(out) && !/>珠</.test(out), '不应再出现文字色块');
assert.ok(!/class="resultbar"[\s\S]{0,300}id="gift"/.test(html), 'resultbar 内不应再有礼物折算');

// 经验区已精简为「卡片 + 默认最高级 + 自己搭配」
assert.ok(out.includes('默认全用最高级'), '经验书应有默认方案');
assert.ok(!out.includes('id="expConcl"'), '旧的方案结论框已删除');
assert.ok(plain.includes('2,000') || out.includes('2,000') || out.includes('9,'), '应出现带千分位的大数字');

console.log('\nSMOKE OK — 单文件 UI 可加载、init 无异常、计算内核可用');
