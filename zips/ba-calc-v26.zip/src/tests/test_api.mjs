/**
 * 对外 API 测试：calculateMaterials / calculateMany
 * 运行：node tests/test_api.mjs
 */
import assert from 'node:assert/strict';
import { calculateMaterials, calculateMany, students } from '../api.mjs';

let pass = 0, fail = 0;
const test = (name, fn) => {
  try { fn(); console.log('PASS  ' + name); pass++; }
  catch (e) { console.log('FAIL  ' + name + '\n       ' + e.message); fail++; }
};

const CUR = { star: 3, skill: '5777', level: 1, bond: 1, equip: [{ tier: 1, level: 1 }, { tier: 1, level: 1 }, { tier: 1, level: 1 }] };
const TGT = { star: 6, skill: '5MMM', level: 90, bond: 100, equip: [{ tier: 10, level: 10 }, { tier: 10, level: 10 }, { tier: 10, level: 10 }] };

test('全量角色已加载（194）', () => {
  assert.equal(students.length, 194);
  assert.equal(students.filter((s) => s.school === 'Trinity').length > 0, true);
});

test('calculateMaterials 返回标准结构 { materials, credits, exp }', () => {
  const r = calculateMaterials(10000, CUR, TGT);
  assert.ok(Array.isArray(r.materials) && r.materials.length > 10, 'materials 必须是数组');
  assert.equal(typeof r.credits, 'number');
  assert.equal(typeof r.exp, 'number');
  assert.equal(r.exp, 1249185);
  assert.ok(r.credits > 8000000, '信用点应大于 800 万');
  const m = r.materials[0];
  for (const k of ['key', 'kind', 'school', 'schoolCn', 'rarity', 'base', 'name', 'need']) {
    assert.ok(k in m, `材料行缺少字段 ${k}`);
  }
  console.log(`      └ ${r.name}: ${r.materials.length} 行材料 / 信用点 ${r.credits} / 经验 ${r.exp}`);
});

test('技能简写支持字符串与对象两种写法', () => {
  const a = calculateMaterials(10000, { skill: '5777' }, { skill: '5MMM' });
  const b = calculateMaterials(10000, { skill: { ex: 5, basic: 7, enhance: 7, sub: 7 } },
                                      { skill: { ex: 5, basic: 10, enhance: 10, sub: 10 } });
  assert.deepEqual(a.materials.map((x) => [x.key, x.need]), b.materials.map((x) => [x.key, x.need]));
});

test('inventory 传入后自动算缺口', () => {
  const r0 = calculateMaterials(10000, CUR, TGT);
  const inv = Object.fromEntries(r0.materials.map((m) => [m.key, m.need]));
  inv.credit = r0.credits;                       // 信用点也走同一套库存
  const r1 = calculateMaterials(10000, CUR, TGT, { inventory: inv });
  assert.equal(r1.materials.every((m) => m.gap === 0 && m.satisfied), true);
  assert.equal(r1.credit.gap, 0);
  assert.equal(r1.credit.need, r0.credits);
});

test('未知角色 id 抛错', () => {
  assert.throws(() => calculateMaterials(999999, {}, {}), /未找到学生/);
});

test('calculateMany 合并多角色并保留来源', () => {
  const r = calculateMany([
    { studentId: 10000, current: CUR, target: TGT },                 // 爱露 歌赫娜
    { studentId: 16000, current: CUR, target: TGT },                 // 春香 歌赫娜
  ]);
  assert.equal(r.count, 2);
  assert.equal(r.detail.length, 2);
  assert.ok(r.materials.length > 5);
  assert.ok(r.materials.some((m) => m.by.length === 2), '应有材料被两名角色共同消耗（同校 BD/笔记/强化珠）');
  console.log(`      └ 合并 ${r.materials.length} 行 / 信用点 ${r.credits}`);
});

test('不改输入对象（纯函数）', () => {
  const cur = JSON.parse(JSON.stringify(CUR));
  calculateMaterials(10000, cur, TGT);
  assert.deepEqual(cur, CUR);
});

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
