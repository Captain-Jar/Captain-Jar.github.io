/**
 * 第二阶段单元测试：覆盖验收标准 7 条
 * 运行：node tests/test_calc.mjs
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  parseSkillNotation, formatSkillLevels,
  calcSkillDelta, calcStarDelta, calcEquipDelta, calcExpDelta, calcBondDelta, applyInventory,
} from '../calc.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA = path.join(__dirname, '..', 'data');
const S = JSON.parse(fs.readFileSync(path.join(DATA, 'students.json'), 'utf8')).students;
const T = JSON.parse(fs.readFileSync(path.join(DATA, 'global.json'), 'utf8'));

const aru = S.find((s) => s.id === 10000);      // 爱露 3★ 歌赫娜
const suzumi = S.find((s) => s.id === 16003);   // 铃美 1★ 崔尼蒂

const find = (res, kind, rarity, base) =>
  res.materials.find((m) => m.kind === kind && m.rarity === rarity && m.base === base);

const tests = [];
const test = (name, fn) => tests.push({ name, fn });

/* ---------- 1. 技能 5777 → 5MMM（只含 7→10 段） ---------- */
test('① 爱露 5777 → 5MMM 只输出 7→10 区间，并按学校+稀有度分组', () => {
  const cur = { ex: 5, basic: 7, enhance: 7, sub: 7 };
  const tgt = { ex: 5, basic: 10, enhance: 10, sub: 10 };
  const r = calcSkillDelta(aru, cur, tgt, T);

  // 三项普通技能各 8+12=20 个紫笔记 → 合计 60
  assert.equal(find(r, 'note', '紫', '技术笔记')?.n, 60, '紫技术笔记 = (8+12)×3 项 = 60');
  assert.equal(find(r, 'note', '金', '技术笔记')?.n, 36, '金技术笔记 = 12×3 = 36');
  assert.equal(find(r, 'artifact', '紫', '完整的罗洪特写本')?.n, 39, '紫古物 = (4+9)×3 = 39');
  assert.equal(find(r, 'artifact', '金', '完稿的罗洪特写本')?.n, 69, '金古物 = (7+16)×3 = 69');
  assert.equal(find(r, 'note', '紫', '秘仪之书')?.n, 3, 'Lv9→10 秘仪之书 ×3');

  // 7→10 区间不应出现白色材料（白只出现在 Lv2→Lv7 段），也不应出现 BD
  assert.ok(!r.materials.some((m) => m.rarity === '白'), '7→10 段不应含白色材料');
  assert.ok(!r.materials.some((m) => m.kind === 'bd'), '普通技能不应出现战术教育光盘');

  const labels = r.materials.map((m) => m.label).join(' / ');
  console.log('    └ 分组结果：', labels);
});

/* ---------- 2. 1★ vs 3★ 升到专四，神明文字不同 ---------- */
test('② 铃美(1★)→专四=830，爱露(3★)→专四=720', () => {
  const a = calcStarDelta(suzumi, 1, 8, T);
  const b = calcStarDelta(aru, 3, 8, T);
  // 30 + 80 + 100 + 120 + 120 + 180 + 200 = 830（与 wiki 累计一致）
  assert.equal(a.materials[0].n, 30 + 80 + 100 + 120 + 120 + 180 + 200, '1★→专四应为 830');
  assert.equal(b.materials[0].n, 100 + 120 + 120 + 180 + 200, '3★→专四应为 720');
  assert.equal(a.materials[0].initialStar, 1);
  assert.equal(b.materials[0].initialStar, 3);
  assert.notEqual(a.materials[0].n, b.materials[0].n);
  console.log(`    └ 1★=${a.materials[0].n} / 3★=${b.materials[0].n} / 信用点 ${a.credit}（部分阶段待补）`);
});

/* ---------- 3. 装备 T3→T6、强化 1→5：图纸与强化珠分开 ---------- */
test('③ 装备 T3→T6 + 强化 1→5：图纸按阶分组，强化珠单独一行', () => {
  const cur = [{ tier: 3, level: 1 }, { tier: 3, level: 1 }, { tier: 3, level: 1 }];
  const tgt = [{ tier: 6, level: 5 }, { tier: 6, level: 5 }, { tier: 6, level: 5 }];
  const r = calcEquipDelta(aru, cur, tgt, T);

  const bps = r.materials.filter((m) => m.kind === 'blueprint');
  const stones = r.materials.filter((m) => m.kind === 'enhanceStone');

  // 单件跨 T4/T5/T6：T4 阶 30+15、T5 阶 35、T6 阶 40；T3 阶 20+5、T2 阶 10；× 3 件
  const byTier = {};
  for (const m of bps) byTier[m.rarity] = (byTier[m.rarity] || 0) + m.n;
  assert.deepEqual(byTier, { T2: 30, T3: 75, T4: 135, T5: 105, T6: 120 }, '图纸数量必须与游戏内升级界面一致');

  const expNeed = Math.round((5456 + 12326 + 17326 + 23551 * 4 / 9) * 3);   // 补满 T3 + 中间 T4/T5 + T6 到 Lv5
  assert.equal(expNeed, 136725);
  assert.equal(stones.length, 1, '强化珠必须只出现一行');
  assert.equal(stones[0].expNeeded, expNeed, '强化经验总量');
  assert.equal(stones[0].n, Math.ceil(expNeed / 5760), '紫珠 = ceil(经验/5760) = 48');
  assert.equal(r.credit, (74304 + 119304 + 169204) * 3, '装备信用点 = 各阶级信用点之和 ×3 件');
  assert.ok(bps.every((m) => /T\d/.test(m.rarity)), '图纸必须带 T 阶');
  console.log('    └ 图纸：', Object.entries(byTier).map(([k, v]) => `${k}×${v}`).join(' / '),
              ' | 强化珠：', stones[0].n, '颗（', expNeed, '经验，信用点', r.credit, '）');
});

/* ---------- 4. 1 级→90 级：经验 + 3 种书方案 + 信用点 ---------- */
test('④ 1→90 级：总经验 1,249,185 + 3 种经验书方案 + 信用点', () => {
  const r = calcExpDelta(1, 90, T);
  assert.equal(r.exp, 1249185, '1→90 总经验必须等于 wiki 表内 Total 1,249,185');
  assert.equal(r.plans.length, 3, '至少 3 种方案');
  assert.deepEqual(r.plans.map((p) => p.name), ['全紫书', '紫+金混合', '全金书']);
  assert.equal(r.plans[0].紫, 125, '全紫书 = ceil(1249185/10000) = 125');
  assert.equal(r.plans[2].金, 625, '全金书 = ceil(1249185/2000) = 625');
  assert.equal(r.credit, 1249185 * 7, '信用点 = 经验 × 7（wiki data-creditprice=7）');
  console.log('    └ 总经验', r.exp, '| 方案', r.plans.map((p) => `${p.name}(紫${p.紫}/金${p.金})`).join(' '), '| 信用点', r.credit);
});

/* ---------- 5. 好感 10→20：独立模块，主材料为空 ---------- */
test('⑤ 好感 10→20：独立区域，主材料清单无礼物条目', () => {
  const r = calcBondDelta(10, 20, T, '3★最爱礼物');
  const expect = T.bond.table.slice(9, 19).reduce((a, b) => a + b, 0);
  assert.equal(r.exp, expect);
  assert.equal(expect, 1545, '10→20 逐级经验 = 1545');
  assert.equal(r.materials.length, 0, '好感度不应产生主材料');
  assert.ok(r.gifts.length >= 3, '应给出多种礼物折算');
  assert.equal(r.picked.name, '3★最爱礼物');
  assert.equal(r.picked.count, Math.ceil(1545 / 180));
  console.log(`    └ 还需好感 ${r.exp} → ${r.picked.name} ${r.picked.count} 个（其他：${r.gifts.filter(g=>g.name!==r.picked.name).map(g=>g.name+' '+g.count).join('、')}）`);
});

/* ---------- 6. 库存对比 ---------- */
test('⑥ 库存：清空=需求，部分=减少，满足=已满足', () => {
  const demand = calcSkillDelta(aru, { ex: 5, basic: 7, enhance: 7, sub: 7 }, { ex: 5, basic: 10, enhance: 10, sub: 10 }, T);

  const empty = applyInventory(demand, {});
  assert.ok(empty.rows.every((r) => r.gap === r.need), '未填库存时 缺口=需求');

  const key = empty.rows[0].key;
  const half = applyInventory(demand, { [key]: Math.floor(empty.rows[0].need / 2) });
  const rowHalf = half.rows.find((r) => r.key === key);
  assert.equal(rowHalf.gap, rowHalf.need - rowHalf.have);
  assert.ok(rowHalf.gap < rowHalf.need, '填了库存缺口必须变小');

  const full = applyInventory(demand, Object.fromEntries(empty.rows.map((r) => [r.key, r.need])));
  assert.ok(full.rows.every((r) => r.satisfied && r.gap === 0), '全部填满后应标记已满足');
  console.log('    └ 需求/持有/缺口 三列 OK，已满足项：', full.rows.filter(r => r.satisfied).length, '条');
});

/* ---------- 7. 简写解析 ---------- */
test('⑦ 技能简写 m / 7 / 57m / 5MMM', () => {
  assert.deepEqual(parseSkillNotation('m'), { ex: 5, basic: 10, enhance: 10, sub: 10 });
  assert.deepEqual(parseSkillNotation('M'), { ex: 5, basic: 10, enhance: 10, sub: 10 });
  assert.deepEqual(parseSkillNotation('7'), { ex: 5, basic: 7, enhance: 7, sub: 7 });
  assert.deepEqual(parseSkillNotation('57m'), { ex: 5, basic: 7, enhance: 10, sub: 10 });
  assert.deepEqual(parseSkillNotation('5MMM'), { ex: 5, basic: 10, enhance: 10, sub: 10 });
  assert.deepEqual(parseSkillNotation('9'), { ex: 5, basic: 9, enhance: 9, sub: 9 });
  assert.equal(parseSkillNotation('abc'), null);
  assert.equal(formatSkillLevels(parseSkillNotation('m')), '5MMM');
  console.log('    └ m→5MMM, 7→5777, 57m→57MM, 非法输入→null');
});

/* ---------- 额外：普通技能 Lv1→2 = 白笔记×5 + 5,000 信用点（游戏内实测） ---------- */
test('⑧ 普通技能从 1 级起练：Lv1→2 = 白笔记×5 + 5,000 信用点，且无告警', () => {
  const r = calcSkillDelta(aru, { ex: 5, basic: 1, enhance: 1, sub: 1 }, { ex: 5, basic: 2, enhance: 2, sub: 2 }, T);
  assert.equal(find(r, 'note', '白', '技术笔记')?.n, 15, '3 项技能 × 笔记 5 = 15');
  assert.equal(r.credit, 3 * 5000, '信用点 3 × 5,000');
  assert.ok(!r.materials.some((m) => m.kind === 'bd'), '普通技能 Lv1→2 不消耗 BD');
  assert.equal(r.warnings.length, 0, '固化数据后不应再有未核实告警');
  console.log('    └ 白笔记 15 / 信用点', r.credit, '| 告警 0 条');
});

/* ---------- 额外：装备 T1→T10 总量必须对上 246,680 ---------- */
test('⑨ 单件装备 T1→T10 累计经验 = 246,680（与用户给的锚点一致）', () => {
  const r = calcEquipDelta(aru, [{ tier: 1, level: 1 }], [{ tier: 10, level: 10 }], T);
  const st = r.materials.find((m) => m.kind === 'enhanceStone');
  assert.equal(st.expNeeded, 246680, '逐级曲线 9 段 × 10 阶 必须回到 246,680');
  console.log('    └ T1→T10 经验', st.expNeeded, '| 紫珠', st.n, '颗 | 信用点', r.credit);
});

/* ---------- 运行 ---------- */
let pass = 0, fail = 0;
for (const t of tests) {
  try {
    t.fn();
    console.log(`PASS  ${t.name}`);
    pass++;
  } catch (e) {
    console.log(`FAIL  ${t.name}`);
    console.log('      ', e.message);
    fail++;
  }
}
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
