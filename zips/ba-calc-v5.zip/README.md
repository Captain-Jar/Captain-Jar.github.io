# 蔚蓝档案 · 养成差量计算器（可集成版）

纯前端 / 纯函数：不联网、不登录、不读游戏接口。计算内核不含任何角色数据，所有材料都来自 `data/*.json`。

三种用法：

| 场景 | 入口 |
|---|---|
| 自己用 | 双击 `index.html`，不用服务器 |
| Node 后端 / 脚本 | `import { calculateMaterials } from './src/api.mjs'` |
| Vue / React / 其他前端 | `import { createCore } from './src/core.js'` + 两份 JSON |

---

## 一、最快的一次调用

```js
// Node：src/api.mjs 已经帮你读好了 JSON
import { calculateMaterials } from './src/api.mjs';

const r = calculateMaterials(
  10000,                                            // 学生 id（SchaleDB Id）
  { star: 3, skill: '5777', level: 1, bond: 1 },    // 当前
  { star: 6, skill: '5MMM', level: 90, bond: 100 }  // 目标
);

console.log(r.credits);    // 11704455
console.log(r.exp);        // 1249185
console.log(r.materials);  // [{ key, kind, school, schoolCn, rarity, base, name, need, have, gap, satisfied, by }]
```

`skill` 支持三种写法：`'5777'`（EX+三技能）、`'5MMM'`（M = 10）、`{ ex:5, basic:7, enhance:7, sub:7 }`。
`equip` 可选，传 `[{tier,level} ×3]`，不传按 T1 Lv1 处理。

## 二、返回结构

```json
{
  "studentId": 10000,
  "name": "爱露",
  "school": "歌赫娜",
  "initialStar": 3,
  "skillText": { "from": "5777", "to": "5MMM" },

  "materials": [
    { "key": "note|Gehenna|紫|技术笔记", "kind": "note", "school": "Gehenna", "schoolCn": "歌赫娜",
      "rarity": "紫", "base": "技术笔记", "name": "歌赫娜 紫技术笔记",
      "need": 60, "have": 0, "gap": 60, "satisfied": false,
      "by": [{ "id": 10000, "name": "爱露", "n": 60 }] }
  ],

  "credits": 11704455,
  "credit": { "need": 11704455, "have": 0, "gap": 11704455, "satisfied": false },

  "exp": 1249185,
  "expBooks": [ { "name": "全紫书", "紫": 125, "金": 0, "overflow": 0 } ],

  "bond": { "exp": 1545, "gifts": [ { "name": "3★最爱礼物", "value": 180, "count": 9 } ], "picked": null },
  "warnings": []
}
```

- `materials[].kind`：`bd` 战术教育光盘 / `note` 技术笔记 / `artifact` 古物 / `blueprint` 图纸 / `enhanceStone` 强化珠 / `secretStone` 神明文字
- `by` 是贡献来源，批量汇总时用它展开“这件材料是谁要的”
- `warnings` 仅在输入越界（如当前星级低于初始星级）时才有内容，正常情况为空数组

### 库存

```js
const r = calculateMaterials(10000, cur, tgt, {
  inventory: { 'note|Gehenna|紫|技术笔记': 30, credit: 5000000 }
});
// 命中的行 gap/satisfied 自动算好
```

### 批量

```js
import { calculateMany } from './src/api.mjs';
const r = calculateMany([
  { studentId: 10000, current: cur, target: tgt },
  { studentId: 16000, current: cur, target: tgt },
]);
// r.materials 已按 key 合并，r.detail 是每人的明细
```

## 三、接 Vue / React

`core.js` 不依赖 Node，只依赖两个 JSON。自己 new 一个 core：

```js
import { createCore } from './core.js';
import studentsFile from './data/students.json';   // Vite/webpack 支持 JSON import
import globalFile from './data/global.json';

const core = createCore({
  students: studentsFile.students,   // 数组
  global: globalFile,
});

export const calculateMaterials = core.calculateMaterials;
```

浏览器里直接 `<script>` 用单文件版时，`window.BACalc` 就是同一个 core：

```js
const r = window.BACalc.calculateMaterials(10000, cur, tgt);
```

## 四、加角色

`data/students.json` 顶层有三个区：`_meta`（来源）、`schema`（字段说明）、`template`（**可直接复制的空壳**）、`students`（数组）。

复制 `template` 改字段即可。最小可用字段：

```json
{
  "id": 99999, "name": "新角色", "nameJp": "ニュー", "school": "Trinity", "schoolCn": "崔尼蒂",
  "initialStar": 3,
  "equipment": [{"slot": "Hat", "slotCn": "帽子"}, {"slot": "Hairpin", "slotCn": "发夹"}, {"slot": "Watch", "slotCn": "手表"}],
  "artifacts": [{"rarity": "白", "base": "以太粉末"}],
  "skillEx": [ { "from": 1, "to": 2, "cost": [
      {"id": 3030, "kind": "bd", "rarity": "白", "base": "战术教育光盘", "n": 12},
      {"id": 150,  "kind": "artifact", "rarity": "白", "base": "以太粉末", "n": 18} ]} ],
  "skillNormal": [ { "from": 2, "to": 3, "cost": [
      {"id": 4030, "kind": "note", "rarity": "白", "base": "技术笔记", "n": 5} ]} ],
  "loveItem": null, "uniqueWeapon": null
}
```

要点：

- `skillEx` 必须 4 段（EX1→2 … EX4→5），`skillNormal` 必须 8 段（Lv2→3 … Lv9→10）；**Lv1→2 不在数组里**，由 `global.skillLv2Cost` 统一处理
- 古物名写具体名字（`base`），不要写“古物”；同一角色可有多套古物（如铃美同时用“以太粉末”和“费斯托斯圆盘碎片”）
- `school` 用 SchaleDB 的 key（`Gehenna`/`Trinity`/`Millennium`/`Abydos`/`Shanhaijing`/`Hyakkiyako`/`RedWinter`/`Valkyrie`/`SRT`/`Arius`），`schoolCn` 是显示名，材料按 `school` 分组
- 新增学校只需在 `school` 里写新 key，`calc.js` 不认识任何学校名

改完跑一次：

```
node src/build.mjs      # 重新生成 src/dist/index.html
```

## 五、目录

```
index.html              单文件应用（194 名角色，双击即用）
README.md
src/
├─ calc.js              5 个原子函数（只做加减法，无角色数据）
├─ core.js              createCore → calculateMaterials / calculateMany
├─ api.mjs              Node 入口（已读好 JSON）
├─ build.mjs            node src/build.mjs → src/dist/index.html
├─ data/students.json   194 名角色 + schema + template
├─ data/global.json     全局表（经验/好感/星级/装备/信用点/礼物）
├─ ui/                  app.js / app.css（界面层）
└─ tests/               test_calc.mjs（9）test_api.mjs（7）smoke_ui.mjs（1）
```

## 六、数据来源

| 表 | 值 | 来源 |
|---|---|---|
| 技能材料（BD/笔记/古物） | 全 194 角色 | SchaleDB |
| 角色经验 1→90 | 合计 1,249,185 | bluearchive.wiki Character Exp table |
| 好感经验 1→100 | 合计 240,225 | bluearchive.wiki Affection Exp table |
| 技能 Lv1→2 | BD×12 / 古物×18 / 信用点 80,000 | 实机核对（与 EX 一致） |
| 神明文字 | 15 / 30 / 100 / 120 / 150 | 实机核对 |
| 装备图纸 | 主+副逐阶 | 实机核对 |
| 强化珠经验 | 90 / 360 / 1440 / 5760 | 实机核对 |
| 装备信用点 | 经验 ×4 | 实机核对 |
| 单件装备 T1→T10 | 246,680 经验 | 实机核对 |
| 角色信用点 | 经验 ×7 | wiki 表参数 |

所有数值已固化为确定值，界面不再出现“待核实”提示。

## 七、界面上的两个 OR 模块

- **角色经验**：三种喂书方案并列显示，标题下写明「以下为多种喂书方案，任选其一即可（OR）」
- **好感度**：各档礼物折算并列显示，写明「以下为不同礼物折算方案，任选其一即可（OR）」

两处都有一个「填入我现有的经验书 / 礼物」折叠入口：填入后先扣库存，再给出直白结论，例如

```
库存抵扣后还需 949,185 经验 → 约 475 本金书（或 95 本紫书）
库存抵扣后还需 1,545 好感 → 还需 9 个3★最爱礼物
```

库存会跟配置一起存进 localStorage 和导出的 JSON。

## 八、界面素材（头像 / 材料图标）

图片走 SchaleDB 官方仓库的公开素材，通过 jsDelivr CDN 加载：

```
角色头像  https://cdn.jsdelivr.net/gh/SchaleDB/SchaleDB@main/images/student/icon/{学生ID}.webp
材料图标  https://cdn.jsdelivr.net/gh/SchaleDB/SchaleDB@main/images/item/icon/{icon名}.webp
```

- `icon名` 来自 `students.json` 每条 cost 的 `icon` 字段（由 SchaleDB items.json 的 `Icon` 带出）
- 图中没有的类别（图纸 / 强化珠 / 神明文字 / 信用点）用内置渐变字块占位，不会裂图
- 所有 `<img>` 都挂了 `onerror`：先自动切到 GitHub raw 备源，仍失败则隐藏该图（不留裂图）

## 九、v5 新增

- **夜间模式**：右上角 🌙/☀️ 一键切换，写入 `localStorage['ba-theme']`，默认跟随系统
- **视觉分级**：缺口 >0 的行淡红底（`#fff5f5`），缺口 =0 的行灰度 + 变浅
- **图片规格**：头像 48px、材料图标 32px，加载失败直接隐藏
- **导入存档**：支持本项目导出格式、`{plan,inv}`、`{students:[{id,current,target}]}`、`{10000:{...}}` 四种结构；识别失败会提示且不动原数据
- **配置折叠**：移动端「收起配置 ▴」一键折叠搜索与角色卡
- **经验降级提示**：紫书不足时给出「X 本金书 + Y 本蓝书」等价方案
- **爱用品**：有数据的角色可勾选计入材料；专武因无数据置灰「暂无数据」
- **养成建议**：按 SchaleDB 的 `TacticRole`（输出/治疗/辅助/坦克/载具）给出固定规则建议
- **PWA**：`manifest.json` + `sw.js`，用 http(s) 打开可「添加到主屏幕」并离线使用；双击 `file://` 打开时自动跳过注册

**未实现（不编造）**：掉落关卡与体力预估。SchaleDB 的 `stages.json` 里掉落用的是另一套物品 id（如 `2107004`），与材料表的 `3030`/`150` 对不上，需要先做一次完整 id 映射才能保证关卡号不出错，因此这一项留空。
