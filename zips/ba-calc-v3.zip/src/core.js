/**
 * 对外 API 层：把 5 个原子函数封装成“给角色 ID + 当前/目标练度，返回材料 JSON”
 * ------------------------------------------------------------
 * 浏览器：window.BACalc.calculateMaterials(10000, cur, tgt)
 * Node  ：import { calculateMaterials } from './api.mjs'
 *
 * 本文件不含任何角色数据，所有材料都来自 createCore 传入的 students / global。
 */
import {
  calcSkillDelta, calcStarDelta, calcEquipDelta, calcExpDelta, calcBondDelta,
  parseSkillNotation, formatSkillLevels, applyInventory,
} from './calc.js';

const DEFAULT_SKILL = { ex: 1, basic: 1, enhance: 1, sub: 1 };

function normSkill(v) {
  if (!v) return { ...DEFAULT_SKILL };
  if (typeof v === 'string') return parseSkillNotation(v) || { ...DEFAULT_SKILL };
  return {
    ex: Number(v.ex ?? 1), basic: Number(v.basic ?? 1),
    enhance: Number(v.enhance ?? 1), sub: Number(v.sub ?? 1),
  };
}

function normCfg(raw, s) {
  const r = raw || {};
  const eqRaw = r.equip || r.equips;
  const equip = s.equipment.map((_, i) => {
    const e = (eqRaw && eqRaw[i]) || {};
    return { tier: Number(e.tier ?? 1), level: Number(e.level ?? 1) };
  });
  return {
    star: Number(r.star ?? s.initialStar),
    skill: normSkill(r.skill),
    equip,
    level: Number(r.level ?? 1),
    bond: Number(r.bond ?? 1),
  };
}

/** 把多个 delta 结果合成一份材料表，并记录来源角色 */
function mergeInto(map, res, student) {
  for (const m of res.materials) {
    const cur = map.get(m.key);
    if (cur) { cur.need += m.n; cur.by.push({ id: student.id, name: student.name, n: m.n }); }
    else map.set(m.key, {
      key: m.key, kind: m.kind, school: m.school, schoolCn: student.schoolCn,
      rarity: m.rarity, base: m.base, name: m.label, need: m.n,
      by: [{ id: student.id, name: student.name, n: m.n }],
    });
  }
}

export function createCore(data) {
  const fileStudents = data?.students;
  const students = Array.isArray(fileStudents) ? fileStudents : (fileStudents?.students || []);
  const global = data?.global || data?.globalFile || data;
  const byId = new Map(students.map((s) => [s.id, s]));

  function getStudent(id) {
    const s = byId.get(Number(id));
    if (!s) throw new Error(`未找到学生 id=${id}`);
    return s;
  }

  /**
   * 计算单个角色从 current 到 target 的养成缺口
   * @returns {{studentId:number,name:string,materials:Array,credits:number,exp:number,
   *            expBooks:Array,bond:Object,warnings:Array}}
   */
  function calculateMaterials(studentId, currentData = {}, targetData = {}, options = {}) {
    const s = getStudent(studentId);
    const cur = normCfg(currentData, s);
    const tgt = normCfg(targetData, s);

    const skill = calcSkillDelta(s, cur.skill, tgt.skill, global);
    const star = calcStarDelta(s, cur.star, tgt.star, global);
    const equip = calcEquipDelta(s, cur.equip, tgt.equip, global);
    const expRes = calcExpDelta(cur.level, tgt.level, global);
    const bond = calcBondDelta(cur.bond, tgt.bond, global, options.gift);

    const map = new Map();
    mergeInto(map, skill, s);
    mergeInto(map, star, s);
    mergeInto(map, equip, s);

    const materials = [...map.values()].sort((a, b) => b.need - a.need || a.name.localeCompare(b.name));
    materials.forEach((m) => { m.n = m.need; });          // applyInventory 以 n 为需求字段
    const credits = skill.credit + star.credit + equip.credit + expRes.credit;

    let out = materials.map((m) => ({ ...m, have: 0, gap: m.need, satisfied: false }));
    let creditRow = { need: credits, have: 0, gap: credits, satisfied: false };
    if (options.inventory) {
      const applied = applyInventory({ materials, credit: credits }, options.inventory);
      out = applied.rows.map((r) => ({ ...r, name: r.label || r.name }));
      creditRow = applied.credit;
    }

    return {
      studentId: s.id,
      name: s.name,
      school: s.schoolCn,
      initialStar: s.initialStar,
      skillText: { from: formatSkillLevels(cur.skill), to: formatSkillLevels(tgt.skill) },
      materials: out,
      credits,
      credit: creditRow,          // 含 have / gap 的信用点行
      exp: expRes.exp,
      expBooks: expRes.plans,
      bond: { exp: bond.exp, gifts: bond.gifts, picked: bond.picked },
      warnings: [...skill.warnings, ...star.warnings, ...equip.warnings, ...expRes.warnings],
    };
  }

  /** 批量：entries = [{studentId, current, target}] */
  function calculateMany(entries = [], options = {}) {
    const map = new Map();
    let credits = 0, exp = 0, bondExp = 0;
    const warnings = [];
    const detail = [];
    for (const e of entries) {
      const r = calculateMaterials(e.studentId, e.current, e.target, {});
      detail.push(r);
      credits += r.credits;
      exp += r.exp;
      bondExp += r.bond.exp;
      warnings.push(...r.warnings);
      for (const m of r.materials) {
        const cur = map.get(m.key);
        if (cur) { cur.need += m.need; cur.by.push(...m.by); }
        else map.set(m.key, { ...m, by: [...m.by] });
      }
    }
    let materials = [...map.values()].sort((a, b) => b.need - a.need || a.name.localeCompare(b.name));
    materials.forEach((m) => { m.n = m.need; });
    let creditRow = { need: credits, have: 0, gap: credits, satisfied: false };
    if (options.inventory) {
      const applied = applyInventory({ materials, credit: credits }, options.inventory);
      materials = applied.rows.map((r) => ({ ...r, name: r.label || r.name }));
      creditRow = applied.credit;
    }
    return { count: entries.length, materials, credits, credit: creditRow, exp, bondExp, detail, warnings };
  }

  return { students, global, calculateMaterials, calculateMany, getStudent, formatSkillLevels, parseSkillNotation };
}
