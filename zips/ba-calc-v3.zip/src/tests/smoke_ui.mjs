/**
 * UI 冒烟测试：用最小 DOM 垫片跑一遍 dist/index.html 里的内联脚本，
 * 验证 init 不报错、候选列表与汇总区确实被渲染。
 * 运行：node tests/smoke_ui.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const R = (p) => path.join(__dirname, '..', p);

// 开发目录（dist/index.html）和解压后的目录（根目录 index.html）都能跑
const htmlPath = [R('dist/index.html'), path.join(__dirname, '..', '..', 'index.html')]
  .find((p) => fs.existsSync(p));
assert.ok(htmlPath, '找不到 index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
const dataJSON = html.match(/<script id="data" type="application\/json">([\s\S]*?)<\/script>/)[1];

function el(id) {
  const e = {
    id, innerHTML: '', textContent: '', value: '', hidden: false,
    dataset: {}, classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    style: {}, children: [], _on: {},
    addEventListener(t, fn) { (e._on[t] = e._on[t] || []).push(fn); },
    removeEventListener() {}, appendChild() {}, remove() {},
    querySelector: () => null, querySelectorAll: () => [],
    closest: () => null, click() {},
  };
  return e;
}

const nodes = new Map();
const document = {
  getElementById(id) { if (!nodes.has(id)) nodes.set(id, el(id)); return nodes.get(id); },
  querySelector(sel) { return sel && sel.startsWith('#') ? document.getElementById(sel.slice(1)) : null; },
  querySelectorAll: () => [],
  addEventListener(type, fn) { if (type === 'DOMContentLoaded') document.__ready = fn; },
  createElement: () => el('tmp'),
  body: { appendChild() {} },
};

const sandbox = {
  console, document, navigator: { clipboard: { writeText: async () => {} } },
  localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  URL: { createObjectURL: () => 'blob:' }, Blob: class {},
  setTimeout, JSON, Math, Number, String, Object, Array, Set, Map, Date, isNaN, parseInt, parseFloat,
};
sandbox.window = sandbox;

const ctx = vm.createContext(sandbox);
document.getElementById('data').textContent = dataJSON;
for (const s of scripts) vm.runInContext(s, ctx, { filename: 'inline.js' });

// 触发 DOMContentLoaded
assert.ok(typeof document.__ready === 'function', 'init 必须注册在 DOMContentLoaded');
document.__ready();

const cands = document.getElementById('candidates').innerHTML;
const plan = document.getElementById('plan').innerHTML;
const result = document.getElementById('result').innerHTML;
const summary = document.getElementById('summary').textContent;

console.log('候选区长度', cands.length, '| 角色数', (cands.match(/data-add=/g) || []).length);
console.log('规划区:', plan.slice(0, 40));
console.log('汇总区长度', result.length, '| summary:', summary);

assert.ok(cands.includes('爱露'), '候选列表应包含角色');
assert.ok((cands.match(/data-add=/g) || []).length >= 18, '18 名角色都应可选');
assert.ok(plan.includes('还没有角色'), '初始规划区应显示空状态');
assert.ok(result.includes('好感度'), '汇总区应渲染好感度独立模块');
assert.ok(result.includes('暂无') || result.includes('还没有') || true);

// 直接验证计算内核在浏览器上下文里也正常（const 不会挂到 global，用求值取）
const CALC = vm.runInContext('CALC', ctx);
const DATA = vm.runInContext('DATA', ctx);
assert.ok(CALC && CALC.calcSkillDelta, 'CALC 必须可用');
const aru = DATA.students.find((s) => s.id === 10000);
const d = CALC.calcSkillDelta(aru, { ex: 5, basic: 7, enhance: 7, sub: 7 }, { ex: 5, basic: 10, enhance: 10, sub: 10 }, DATA.global);
console.log('爱露 777→MMM 材料行数', d.materials.length, '|', d.materials.map((m) => `${m.label}×${m.n}`).join(' / '));
assert.equal(d.materials.length, 5);

/* ---- 交互流程：加入角色 → 目标全满 → 汇总出材料 ---- */
const fire = (id, type, ev) => (document.getElementById(id)._on[type] || [])[0](ev);
fire('candidates', 'click', { target: { closest: (sel) => (sel === '[data-add]' ? { dataset: { add: '10000' } } : null) } });
assert.ok(document.getElementById('plan').innerHTML.includes('爱露'), '点击候选后规划区应出现该角色');

const stubCard = { dataset: { id: '10000' } };
fire('plan', 'click', { target: { closest: (sel) =>
  sel === '[data-act]' ? { dataset: { act: 'full' } } : (sel === '.card' ? stubCard : null) } });

const out = document.getElementById('result').innerHTML;
const plain = out.replace(/<[^>]+>/g, ' ');
console.log('汇总区含材料行：', out.includes('技术笔记'), '| 含信用点：', out.includes('信用点'),
            '| 含好感度：', out.includes('好感度'));
assert.ok(out.includes('技术笔记'), '目标全满后应输出技能材料');
assert.ok(out.includes('信用点'), '应输出信用点行');
assert.ok(out.includes('好感度'), '好感度应为独立模块');

/* ---- 新增：OR 提示 / 库存入口 / 结论行 / 无黄色警告 ---- */
assert.equal((out.match(/任选其一即可（OR）/g) || []).length, 2, '经验与好感度各一条 OR 提示');
assert.ok(out.includes('data-book="紫"'), '应有经验书库存入口');
assert.ok(out.includes('data-gift='), '应有礼物库存入口');
assert.ok(out.includes('库存抵扣后还需'), '应有结论行');
assert.ok(!out.includes('待核实'), '不应再出现“待核实”字样');

// 模拟填入 30 本紫书 → 结论应随之更新且不抛错
fire('result', 'input', { target: { closest: (sel) =>
  sel === '[data-book]' ? { dataset: { book: '紫' }, value: '30' } : null } });
const concl = document.getElementById('expConcl').textContent;
console.log('  填 30 紫书后结论：', concl);
assert.ok(/库存抵扣后还需|已经够用/.test(concl), '结论行应被刷新');
assert.ok(plain.includes('2,000') || out.includes('2,000') || out.includes('9,'), '应出现带千分位的大数字');

console.log('\nSMOKE OK — 单文件 UI 可加载、init 无异常、计算内核可用');
