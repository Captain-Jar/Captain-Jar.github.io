# 蔚蓝档案 · 养成差量计算器（可集成版）

纯前端 / 纯函数：不联网、不登录、不读游戏接口。计算内核不含任何角色数据，所有材料都来自 `data/*.json`。

三种用法：

| 场景 | 入口 |
|---|---|
| 自己用 | 双击 `index.html`，不用服务器 |
| Node 后端 / 脚本 | `import { calculateMaterials } from './src/api.mjs'` |
| Vue / React / 其他前端 | `import { createCore } from './src/core.js'` + 两份 JSON |

---

## 一、最快的一次调用

```js
// Node：src/api.mjs 已经帮你读好了 JSON
import { calculateMaterials } from './src/api.mjs';

const r = calculateMaterials(
  10000,                                            // 学生 id（SchaleDB Id）
  { star: 3, skill: '5777', level: 1, bond: 1 },    // 当前
  { star: 6, skill: '5MMM', level: 90, bond: 100 }  // 目标
);

console.log(r.credits);    // 11704455
console.log(r.exp);        // 1249185
console.log(r.materials);  // [{ key, kind, school, schoolCn, rarity, base, name, need, have, gap, satisfied, by }]
```

`skill` 支持三种写法：`'5777'`（EX+三技能）、`'5MMM'`（M = 10）、`{ ex:5, basic:7, enhance:7, sub:7 }`。
`equip` 可选，传 `[{tier,level} ×3]`，不传按 T1 Lv1 处理。

## 二、返回结构

```json
{
  "studentId": 10000,
  "name": "爱露",
  "school": "歌赫娜",
  "initialStar": 3,
  "skillText": { "from": "5777", "to": "5MMM" },

  "materials": [
    { "key": "note|Gehenna|紫|技术笔记", "kind": "note", "school": "Gehenna", "schoolCn": "歌赫娜",
      "rarity": "紫", "base": "技术笔记", "name": "歌赫娜 紫技术笔记",
      "need": 60, "have": 0, "gap": 60, "satisfied": false,
      "by": [{ "id": 10000, "name": "爱露", "n": 60 }] }
  ],

  "credits": 11704455,
  "credit": { "need": 11704455, "have": 0, "gap": 11704455, "satisfied": false },

  "exp": 1249185,
  "expBooks": [ { "name": "全紫书", "紫": 125, "金": 0, "overflow": 0 } ],

  "bond": { "exp": 1545, "gifts": [ { "name": "3★最爱礼物", "value": 180, "count": 9 } ], "picked": null },
  "warnings": [ { "code": "SKILL_LV2_INFERRED", "unverified": true, "msg": "…" } ]
}
```

- `materials[].kind`：`bd` 战术教育光盘 / `note` 技术笔记 / `artifact` 古物 / `blueprint` 图纸 / `enhanceStone` 强化珠 / `secretStone` 神明文字
- `by` 是贡献来源，批量汇总时用它展开“这件材料是谁要的”
- `warnings` 里 `unverified: true` 的条目要在 UI 上标灰，别当成确定值

### 库存

```js
const r = calculateMaterials(10000, cur, tgt, {
  inventory: { 'note|Gehenna|紫|技术笔记': 30, credit: 5000000 }
});
// 命中的行 gap/satisfied 自动算好
```

### 批量

```js
import { calculateMany } from './src/api.mjs';
const r = calculateMany([
  { studentId: 10000, current: cur, target: tgt },
  { studentId: 16000, current: cur, target: tgt },
]);
// r.materials 已按 key 合并，r.detail 是每人的明细
```

## 三、接 Vue / React

`core.js` 不依赖 Node，只依赖两个 JSON。自己 new 一个 core：

```js
import { createCore } from './core.js';
import studentsFile from './data/students.json';   // Vite/webpack 支持 JSON import
import globalFile from './data/global.json';

const core = createCore({
  students: studentsFile.students,   // 数组
  global: globalFile,
});

export const calculateMaterials = core.calculateMaterials;
```

浏览器里直接 `<script>` 用单文件版时，`window.BACalc` 就是同一个 core：

```js
const r = window.BACalc.calculateMaterials(10000, cur, tgt);
```

## 四、加角色

`data/students.json` 顶层有三个区：`_meta`（来源）、`schema`（字段说明）、`template`（**可直接复制的空壳**）、`students`（数组）。

复制 `template` 改字段即可。最小可用字段：

```json
{
  "id": 99999, "name": "新角色", "nameJp": "ニュー", "school": "Trinity", "schoolCn": "崔尼蒂",
  "initialStar": 3,
  "equipment": [{"slot": "Hat", "slotCn": "帽子"}, {"slot": "Hairpin", "slotCn": "发夹"}, {"slot": "Watch", "slotCn": "手表"}],
  "artifacts": [{"rarity": "白", "base": "以太粉末"}],
  "skillEx": [ { "from": 1, "to": 2, "cost": [
      {"id": 3030, "kind": "bd", "rarity": "白", "base": "战术教育光盘", "n": 12},
      {"id": 150,  "kind": "artifact", "rarity": "白", "base": "以太粉末", "n": 18} ]} ],
  "skillNormal": [ { "from": 2, "to": 3, "cost": [
      {"id": 4030, "kind": "note", "rarity": "白", "base": "技术笔记", "n": 5} ]} ],
  "loveItem": null, "uniqueWeapon": null, "unverified": false
}
```

要点：

- `skillEx` 必须 4 段（EX1→2 … EX4→5），`skillNormal` 必须 8 段（Lv2→3 … Lv9→10）；**Lv1→2 不在数组里**，由 `global.skillLv2Cost` 统一处理
- 古物名写具体名字（`base`），不要写“古物”；同一角色可有多套古物（如铃美同时用“以太粉末”和“费斯托斯圆盘碎片”）
- `school` 用 SchaleDB 的 key（`Gehenna`/`Trinity`/`Millennium`/`Abydos`/`Shanhaijing`/`Hyakkiyako`/`RedWinter`/`Valkyrie`/`SRT`/`Arius`），`schoolCn` 是显示名，材料按 `school` 分组
- 新增学校只需在 `school` 里写新 key，`calc.js` 不认识任何学校名

改完跑一次：

```
node src/build.mjs      # 重新生成 src/dist/index.html
```

## 五、目录

```
index.html              单文件应用（194 名角色，双击即用）
README.md
src/
├─ calc.js              5 个原子函数（只做加减法，无角色数据）
├─ core.js              createCore → calculateMaterials / calculateMany
├─ api.mjs              Node 入口（已读好 JSON）
├─ build.mjs            node src/build.mjs → src/dist/index.html
├─ data/students.json   194 名角色 + schema + template
├─ data/global.json     全局表（经验/好感/星级/装备/信用点/礼物）
├─ ui/                  app.js / app.css（界面层）
└─ tests/               test_calc.mjs（9）test_api.mjs（7）smoke_ui.mjs（1）
```

## 六、数据可信度

已核实：技能材料（SchaleDB 全量）、经验 1→90（合计 1,249,185）、好感 1→100（合计 240,225）、经验书、礼物、信用点系数、神明文字 15/30/100/120/150、装备图纸（主+副）、强化珠经验 90/360/1440/5760、单件 T1→T10 合计 246,680。

仍标 `unverified`（界面灰字提示）：

- 技能 Lv1→2 的 BD×12 / 古物×18 / 信用点 80,000：实机截图取自 EX1→2，外推到普通技能
- 装备每级经验：按总量 246,680 分 10 阶插值

任何缺失项都会进 `warnings`，不会悄悄写 0。
